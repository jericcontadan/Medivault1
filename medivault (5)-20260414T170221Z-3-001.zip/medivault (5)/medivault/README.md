# MediVault — Health Records System

A personal health records web application with patient and doctor roles.  
Pure HTML + CSS + JavaScript — no framework, no build step, opens directly in a browser.

---

## Project Structure

```
medivault/
├── index.html              ← Entry point — open this in your browser
├── css/
│   └── styles.css          ← All styles (CSS variables, layout, components)
└── js/
    ├── db.js               ← In-memory data store (simulates a database)
    ├── icons.js            ← SVG icon helper functions
    ├── auth.js             ← Login, registration, and auth renderers
    ├── modals.js           ← Modal dialog renderers and save actions
    ├── pages-patient.js    ← Patient-facing page renderers
    ├── pages-doctor.js     ← Doctor-facing page renderers
    └── app.js              ← App state, render engine, navigation (load last)
```

---

## Getting Started

### Option 1 — Open directly (simplest)
Double-click `index.html` in your file explorer.  
The app loads entirely in your browser — no server needed.

### Option 2 — VS Code Live Server (recommended for development)
1. Install the **Live Server** extension in VS Code.
2. Open the `medivault/` folder in VS Code.
3. Right-click `index.html` → **Open with Live Server**.
4. The app opens at `http://127.0.0.1:5500`.

### Option 3 — Any static server
```bash
# Python
python -m http.server 5500

# Node.js (npx)
npx serve .
```

---

## Demo Accounts

| Role    | Email             | Password  |
|---------|-------------------|-----------|
| Patient | maria@demo.com    | demo123   |
| Doctor  | doctor@demo.com   | demo123   |

Or click the **Patient Demo / Doctor Demo** buttons on the login screen.

---

## Features

### Patient View
- **Dashboard** — health overview, quick profile, active meds, allergy alerts
- **My Profile** — personal info, blood type, PhilHealth, HMO, emergency contact
- **Medical History** — illnesses, allergies (with severity), family history
- **Visit Tracker** — log clinic/hospital visits
- **Medications** — current and past medications with dosage and frequency
- **Vaccinations** — immunization records
- **Documents** — placeholder for file uploads (needs backend integration)

### Doctor View
- **Dashboard** — patient count, consultation stats, follow-up schedule
- **Patients** — searchable patient list with blood type, allergies, meds
- **Patient Detail** — full records: consultations, visits, meds, allergies
- **Consultations** — all consultation notes with diagnosis and follow-up dates
- **Schedule** — upcoming follow-up appointments

---

## Architecture Notes

- **No framework** — vanilla JavaScript with template literals for rendering.
- **No build step** — all scripts are loaded via `<script>` tags in order.
- **In-memory data** — `db.js` acts as a mock database. Data resets on page refresh.
  To persist data, replace `DB` reads/writes with `fetch()` calls to a real REST API
  or replace with `localStorage` for client-side persistence.
- **Script load order** is critical — see comments in `index.html`.

---

## Connecting a Real Backend

Replace the in-memory `DB` object in `db.js` with API calls.  
Example pattern:

```javascript
// Instead of: DB.visits.filter(v => v.patient_id === uid)
// Use:
const visits = await fetch(`/api/visits?patient_id=${uid}`).then(r => r.json());
```

Recommended backend options for this stack:
- **Node.js + Express + MySQL** (matches the original MySQL design intent)
- **Supabase** (PostgreSQL with a REST API out of the box)
- **Firebase Firestore** (NoSQL, real-time)
