/**
 * MediVault — pages-patient.js
 * Renderers for all patient-facing pages.
 */

// ============================================================
// PATIENT DASHBOARD
// ============================================================
function renderPatientDashboard() {
  const uid      = currentUser.id;
  const p        = DB.profiles[uid] || {};
  const visits   = DB.visits.filter(v => v.patient_id === uid).sort((a, b) => b.date.localeCompare(a.date));
  const meds     = DB.medications.filter(m => m.patient_id === uid && m.current);
  const allergies= DB.medical_history.filter(m => m.patient_id === uid && m.type === 'allergy');
  const vacc     = DB.vaccinations.filter(v => v.patient_id === uid);
  const lv       = visits[0];
  const days     = lv ? daysSince(lv.date) : null;
  const upcoming = DB.consultations
    .filter(c => c.patient_id === uid && c.follow_up && new Date(c.follow_up) > new Date())
    .sort((a, b) => a.follow_up.localeCompare(b.follow_up))[0];
  const bmi      = calculateBMI(p.height_cm, p.weight_kg);
  const bmiCat   = getBMICategory(bmi);
  const expiredMeds = meds.filter(m => m.expiry && isExpired(m.expiry));

  return `
  <div class="page-header">
    <div class="page-header-left">
      <h2>Good day, ${currentUser.name.split(' ')[0]} 👋</h2>
      <p>Your health overview at a glance</p>
    </div>
  </div>
  <div class="page-body">
    ${days !== null
      ? `<div class="banner-blue">🏥 It's been <strong style="margin:0 4px">${days} day${days !== 1 ? 's' : ''}</strong> since your last checkup on ${lv.date}.${days > 180 ? ' Consider scheduling a visit soon.' : ''}</div>`
      : ''}
    ${upcoming ? `<div class="alert alert-green">📅 Upcoming follow-up: <strong>${upcoming.follow_up}</strong> — ${upcoming.diagnosis}</div>` : ''}
    ${expiredMeds.length > 0 ? `<div class="alert alert-red">⚠️ <strong>${expiredMeds.length}</strong> medication${expiredMeds.length !== 1 ? 's' : ''} expired. Please check with your doctor.</div>` : ''}

    <div class="grid-4" style="margin-bottom:1.25rem">
      <div class="stat-card stat-green"><div class="stat-label">Active Medications</div><div class="stat-value">${meds.length}</div><div class="stat-sub">currently taking</div></div>
      <div class="stat-card stat-blue"><div class="stat-label">Total Visits</div><div class="stat-value">${visits.length}</div><div class="stat-sub">all time</div></div>
      <div class="stat-card stat-amber"><div class="stat-label">Allergies</div><div class="stat-value">${allergies.length}</div><div class="stat-sub">on record</div></div>
      <div class="stat-card stat-purple"><div class="stat-label">Vaccinations</div><div class="stat-value">${vacc.length}</div><div class="stat-sub">recorded</div></div>
    </div>
    ${bmi ? `<div class="grid-4" style="margin-bottom:1.25rem">
      <div class="stat-card stat-purple"><div class="stat-label">BMI</div><div class="stat-value">${bmi}</div><div class="stat-sub">${bmiCat}</div></div>
      <div class="stat-card stat-blue"><div class="stat-label">Height</div><div class="stat-value">${p.height_cm} cm</div><div class="stat-sub">recorded</div></div>
      <div class="stat-card stat-green"><div class="stat-label">Weight</div><div class="stat-value">${p.weight_kg} kg</div><div class="stat-sub">latest</div></div>
      <div class="stat-card stat-amber"><div class="stat-label">Lab Tests</div><div class="stat-value">${DB.lab_results.filter(l => l.patient_id === uid).length}</div><div class="stat-sub">on record</div></div>
    </div>` : ''}

    <div class="grid-2" style="margin-bottom:1.25rem">
      <!-- Quick Profile -->
      <div class="card">
        <div class="card-header"><h3>Quick Profile</h3><button class="btn btn-sm" onclick="navigate('profile')">Edit</button></div>
        <div class="card-body">
          <div style="display:flex;align-items:center;gap:14px;margin-bottom:14px">
            <div class="profile-photo">
              ${currentUser.profilePicture ? `<img src="${currentUser.profilePicture}" alt="Profile Picture" style="width:100%;height:100%;border-radius:50%;object-fit:cover;">` : currentUser.avatar}
            </div>
            <div>
              <div style="font-weight:600;font-size:15px">${p.name || currentUser.name}</div>
              <div style="color:var(--text2);font-size:12px">${p.sex || '—'} &middot; ${p.age ? p.age + ' yrs old' : '—'}</div>
              <div style="margin-top:6px"><span class="badge badge-red">${p.blood_type || 'Blood type not set'}</span></div>
            </div>
          </div>
          <div style="font-size:12px;color:var(--text2);display:grid;gap:7px">
            <div>📍 ${p.address || 'Address not set'}</div>
            <div>📞 ${p.phone || '—'}</div>
            <div>🏥 PhilHealth: <strong style="color:var(--text)">${p.philhealth || '—'}</strong></div>
            <div>💊 HMO: <strong style="color:var(--text)">${p.hmo || '—'}</strong></div>
          </div>
        </div>
      </div>

      <!-- Recent Visits -->
      <div class="card">
        <div class="card-header"><h3>Recent Visits</h3><button class="btn btn-sm" onclick="navigate('visits')">View all</button></div>
        <div class="card-body" style="padding-top:0.75rem">
          ${visits.slice(0, 4).map(v => `
            <div class="timeline-item">
              <div class="timeline-dot"></div>
              <div class="timeline-content">
                <div class="timeline-date">${v.date}</div>
                <div class="timeline-title">${v.reason}</div>
                <div class="timeline-detail">${v.doctor} &middot; ${v.hospital}</div>
              </div>
            </div>`).join('')}
          ${visits.length === 0 ? '<div class="empty-state"><p>No visits recorded yet</p></div>' : ''}
        </div>
      </div>
    </div>

    <div class="grid-2">
      <!-- Active Medications -->
      <div class="card">
        <div class="card-header"><h3>Active Medications</h3><button class="btn btn-sm" onclick="navigate('medications')">Manage</button></div>
        <div class="card-body" style="padding:0">
          ${meds.length === 0 ? '<div class="empty-state" style="padding:1.5rem"><p>No active medications</p></div>' : ''}
          ${meds.map(m => `
            <div style="display:flex;justify-content:space-between;align-items:center;padding:10px 1.25rem;border-bottom:1px solid var(--border)">
              <div>
                <div style="font-size:13px;font-weight:500">${m.name} ${m.expiry && isExpired(m.expiry) ? '⚠️' : ''}</div>
                <div style="font-size:11px;color:var(--text2)">${m.dosage} &middot; ${m.frequency}</div>
                ${m.expiry ? `<div style="font-size:10px;color:${isExpired(m.expiry) ? '#f85149' : '#8b949e'}">${isExpired(m.expiry) ? 'Expired' : 'Expires'}: ${m.expiry}</div>` : ''}
              </div>
              <span class="badge ${m.expiry && isExpired(m.expiry) ? 'badge-red' : 'badge-green'}">${m.expiry && isExpired(m.expiry) ? 'EXPIRED' : 'Active'}</span>
            </div>`).join('')}
        </div>
      </div>

      <!-- Allergy Alerts -->
      <div class="card">
        <div class="card-header"><h3>Allergy Alerts</h3><button class="btn btn-sm" onclick="navigate('medical')">View all</button></div>
        <div class="card-body" style="padding:0">
          ${allergies.length === 0 ? '<div class="empty-state" style="padding:1.5rem"><p>No allergies recorded</p></div>' : ''}
          ${allergies.map(a => `
            <div style="display:flex;justify-content:space-between;align-items:center;padding:10px 1.25rem;border-bottom:1px solid var(--border)">
              <div>
                <div style="font-size:13px;font-weight:500">${a.title}</div>
                <div style="font-size:11px;color:var(--text2)">${a.category || '—'}</div>
              </div>
              <span class="badge ${a.severity === 'Severe' ? 'badge-red' : a.severity === 'Moderate' ? 'badge-amber' : 'badge-blue'}">${a.severity || 'Mild'}</span>
            </div>`).join('')}
        </div>
      </div>
    </div>
  </div>`;
}

// ============================================================
// PROFILE PAGE
// ============================================================
function renderProfile() {
  const uid = currentUser.id;
  const p   = DB.profiles[uid] || {};
  const ec  = DB.emergency[uid] || {};

  return `
  <div class="page-header">
    <div class="page-header-left"><h2>My Profile</h2><p>Personal information and emergency contacts</p></div>
  </div>
  <div class="page-body">
    <div class="grid-2" style="margin-bottom:1.25rem">
      <!-- Personal Info -->
      <div class="card">
        <div class="card-header"><h3>Personal Information</h3></div>
        <div class="card-body">
          <div class="profile-upload-wrapper" style="margin-bottom:1.25rem">
            <div class="profile-photo">
              ${currentUser.profilePicture ? `<img src="${currentUser.profilePicture}" alt="Profile Picture">` : currentUser.avatar}
            </div>
            <div class="profile-upload-actions">
              <div class="profile-name">${currentUser.name}</div>
              <div class="profile-email">${currentUser.email}</div>
              <label for="profile-pic" class="upload-btn">
                <span>Change Photo</span>
                <span class="upload-icon">📷</span>
                <input type="file" id="profile-pic" accept="image/*" onchange="uploadProfilePicture()">
              </label>
              <div class="upload-hint">Square image recommended. Saves automatically.</div>
            </div>
          </div>
          <div class="form-row" style="margin-bottom:12px">
            <div class="form-group"><label>Full Name</label><input id="p-name" value="${p.name || currentUser.name}"></div>
            <div class="form-group"><label>Age</label><input id="p-age" type="number" value="${p.age || ''}"></div>
          </div>
          <div class="form-row" style="margin-bottom:12px">
            <div class="form-group"><label>Birthdate</label><input id="p-bday" type="date" value="${p.birthdate || ''}"></div>
            <div class="form-group">
              <label>Sex</label>
              <select id="p-sex">
                <option ${p.sex === 'Male'   ? 'selected' : ''}>Male</option>
                <option ${p.sex === 'Female' ? 'selected' : ''}>Female</option>
                <option ${p.sex === 'Other'  ? 'selected' : ''}>Other</option>
              </select>
            </div>
          </div>
          <div class="form-row" style="margin-bottom:12px">
            <div class="form-group">
              <label>Blood Type</label>
              <select id="p-blood">${['A+','A-','B+','B-','AB+','AB-','O+','O-'].map(t => `<option ${p.blood_type === t ? 'selected' : ''}>${t}</option>`).join('')}</select>
            </div>
            <div class="form-group"><label>Phone</label><input id="p-phone" value="${p.phone || ''}"></div>
          </div>
          <div class="form-row" style="margin-bottom:12px">
            <div class="form-group"><label>Height (cm)</label><input id="p-height" type="number" value="${p.height_cm || ''}" placeholder="e.g. 165"></div>
            <div class="form-group"><label>Weight (kg)</label><input id="p-weight" type="number" step="0.1" value="${p.weight_kg || ''}" placeholder="e.g. 70.5"></div>
          </div>
          <div class="form-group" style="margin-bottom:12px">
            <label>Address</label>
            <input id="p-address" value="${p.address || ''}">
          </div>
          <div class="form-row" style="margin-bottom:12px">
            <div class="form-group"><label>PhilHealth No.</label><input id="p-philhealth" value="${p.philhealth || ''}"></div>
            <div class="form-group"><label>HMO Provider</label><input id="p-hmo" value="${p.hmo || ''}"></div>
          </div>
          <button class="btn btn-primary" onclick="saveProfile()">Save Profile</button>
          <div id="p-saved" style="margin-top:8px"></div>
        </div>
      </div>

      <!-- Emergency Contact -->
      <div class="card">
        <div class="card-header"><h3>Emergency Contact</h3></div>
        <div class="card-body">
          <div class="form-group"><label>Contact Name</label><input id="ec-name" value="${ec.name || ''}"></div>
          <div class="form-group"><label>Relationship</label><input id="ec-relation" value="${ec.relation || ''}" placeholder="e.g. Spouse, Parent, Sibling"></div>
          <div class="form-group"><label>Phone Number</label><input id="ec-phone" value="${ec.phone || ''}"></div>
          <button class="btn btn-primary" onclick="saveEmergency()">Save Contact</button>
          <div id="ec-saved" style="margin-top:8px"></div>
        </div>
      </div>
    </div>
  </div>`;
}

function saveProfile() {
  DB.profiles[currentUser.id] = {
    name:        v('p-name'),
    age:         v('p-age'),
    birthdate:   v('p-bday'),
    sex:         document.getElementById('p-sex').value,
    blood_type:  document.getElementById('p-blood').value,
    phone:       v('p-phone'),
    address:     v('p-address'),
    philhealth:  v('p-philhealth'),
    hmo:         v('p-hmo'),
    height_cm:   v('p-height') ? parseFloat(v('p-height')) : null,
    weight_kg:   v('p-weight') ? parseFloat(v('p-weight')) : null,
  };
  savePersistedData();
  flash('p-saved', 'Profile saved successfully!');
}

function saveEmergency() {
  DB.emergency[currentUser.id] = {
    name:     v('ec-name'),
    relation: v('ec-relation'),
    phone:    v('ec-phone'),
  };
  savePersistedData();
  flash('ec-saved', 'Emergency contact saved!');
}

// ============================================================
// MEDICAL HISTORY
// ============================================================
function renderMedical() {
  const uid    = currentUser.id;
  const types  = ['illness', 'allergy', 'family'];
  const labels = ['Illnesses & Hospitalizations', 'Allergies', 'Family History'];
  const items  = DB.medical_history.filter(m => m.patient_id === uid && m.type === types[activeTab]);

  return `
  <div class="page-header">
    <div class="page-header-left"><h2>Medical History</h2><p>Past conditions, allergies, and family health background</p></div>
    <button class="btn btn-primary" onclick="openModal('add-hist-${types[activeTab]}')">+ Add Entry</button>
  </div>
  <div class="page-body">
    <div class="tab-group">
      ${labels.map((l, i) => `<button class="tab ${activeTab === i ? 'active' : ''}" onclick="activeTab=${i};render()">${l}</button>`).join('')}
    </div>
    ${items.length === 0 ? `<div class="empty-state"><p>No ${labels[activeTab].toLowerCase()} recorded yet</p></div>` : ''}
    <div style="display:grid;gap:10px">
      ${items.map(item => `
        <div class="card">
          <div class="card-body" style="display:flex;align-items:flex-start;justify-content:space-between;gap:12px">
            <div style="flex:1">
              <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap;margin-bottom:4px">
                <span style="font-size:14px;font-weight:600">${item.title}</span>
                ${item.severity ? `<span class="badge ${item.severity === 'Severe' ? 'badge-red' : item.severity === 'Moderate' ? 'badge-amber' : 'badge-blue'}">${item.severity}</span>` : ''}
                ${item.category ? `<span class="badge badge-purple">${item.category}</span>` : ''}
                ${item.relation ? `<span class="badge badge-blue">${item.relation}</span>` : ''}
              </div>
              ${item.date  ? `<div style="font-size:12px;color:var(--text3)">Date: ${item.date}</div>` : ''}
              ${item.notes ? `<div style="font-size:13px;color:var(--text2);margin-top:4px">${item.notes}</div>` : ''}
            </div>
            <div style="display:flex;gap:4px;flex-shrink:0">
              <button class="btn btn-sm" onclick="openModal('edit-hist-${item.id}')">Edit</button>
              <button class="btn btn-sm btn-danger" onclick="delItem('medical_history',${item.id})">Del</button>
            </div>
          </div>
        </div>`).join('')}
    </div>
  </div>`;
}

// ============================================================
// VISITS
// ============================================================
function renderVisits() {
  const uid    = currentUser.id;
  const visits = DB.visits.filter(v => v.patient_id === uid).sort((a, b) => b.date.localeCompare(a.date));
  const lv     = visits[0];
  const days   = lv ? daysSince(lv.date) : null;

  return `
  <div class="page-header">
    <div class="page-header-left"><h2>Visit & Checkup Tracker</h2><p>Log your clinic and hospital visits</p></div>
    <button class="btn btn-primary" onclick="openModal('add-visit')">+ Log Visit</button>
  </div>
  <div class="page-body">
    ${days !== null ? `<div class="banner-blue">🏥 Last checkup was <strong style="margin:0 4px">${days} day${days !== 1 ? 's' : ''} ago</strong> — ${lv.date} at ${lv.hospital}.</div>` : ''}
    ${visits.length === 0 ? '<div class="empty-state"><p>No visits recorded. Log your first visit!</p></div>' : ''}
    <div style="display:grid;gap:10px">
      ${visits.map(vs => `
        <div class="card">
          <div class="card-body" style="display:flex;align-items:flex-start;justify-content:space-between;gap:12px">
            <div style="flex:1">
              <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap;margin-bottom:4px">
                <span style="font-size:14px;font-weight:600">${vs.reason}</span>
                <span class="badge badge-blue">${vs.date}</span>
              </div>
              <div style="font-size:13px;color:var(--text2)">${vs.doctor} &middot; ${vs.hospital}</div>
              ${vs.notes ? `<div style="font-size:12px;color:var(--text3);margin-top:4px">${vs.notes}</div>` : ''}
            </div>
            <div style="display:flex;gap:4px;flex-shrink:0">
              <button class="btn btn-sm" onclick="openModal('edit-visit-${vs.id}')">Edit</button>
              <button class="btn btn-sm btn-danger" onclick="delItem('visits',${vs.id})">Del</button>
            </div>
          </div>
        </div>`).join('')}
    </div>
  </div>`;
}

// ============================================================
// MEDICATIONS
// ============================================================
function renderMedications() {
  const uid  = currentUser.id;
  const all  = DB.medications.filter(m => m.patient_id === uid);
  const cur  = all.filter(m => m.current);
  const past = all.filter(m => !m.current);

  return `
  <div class="page-header">
    <div class="page-header-left"><h2>Medications Log</h2><p>Current and past medications</p></div>
    <button class="btn btn-primary" onclick="openModal('add-med')">+ Add Medication</button>
  </div>
  <div class="page-body">
    <div class="card" style="margin-bottom:1rem">
      <div class="card-header"><h3>Current Medications</h3><span class="badge badge-green">${cur.length} active</span></div>
      <div class="card-body" style="padding:0">
        ${cur.length === 0 ? '<div class="empty-state" style="padding:1.5rem"><p>No active medications</p></div>' : ''}
        <div class="table-wrap">
          <table>
            <thead><tr><th>Medication</th><th>Dosage</th><th>Frequency</th><th>Since</th><th>Notes</th><th></th></tr></thead>
            <tbody>${cur.map(m => `
              <tr>
                <td style="font-weight:500">${m.name}</td>
                <td>${m.dosage}</td>
                <td>${m.frequency}</td>
                <td>${m.start}</td>
                <td style="color:var(--text2);font-size:12px">${m.notes || '—'}</td>
                <td style="white-space:nowrap">
                  <button class="btn btn-sm" onclick="openModal('edit-med-${m.id}')">Edit</button>
                  <button class="btn btn-sm btn-danger" onclick="delItem('medications',${m.id})">Del</button>
                </td>
              </tr>`).join('')}
            </tbody>
          </table>
        </div>
      </div>
    </div>

    <div class="card">
      <div class="card-header"><h3>Past Medications</h3></div>
      <div class="card-body" style="padding:0">
        ${past.length === 0 ? '<div class="empty-state" style="padding:1.5rem"><p>No past medications</p></div>' : ''}
        <div class="table-wrap">
          <table>
            <thead><tr><th>Medication</th><th>Dosage</th><th>Period</th><th>Notes</th><th></th></tr></thead>
            <tbody>${past.map(m => `
              <tr style="opacity:0.7">
                <td style="font-weight:500">${m.name}</td>
                <td>${m.dosage}</td>
                <td style="font-size:12px">${m.start}${m.end ? ' → ' + m.end : ''}</td>
                <td style="color:var(--text2);font-size:12px">${m.notes || '—'}</td>
                <td style="white-space:nowrap">
                  <button class="btn btn-sm" onclick="openModal('edit-med-${m.id}')">Edit</button>
                  <button class="btn btn-sm btn-danger" onclick="delItem('medications',${m.id})">Del</button>
                </td>
              </tr>`).join('')}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>`;
}

// ============================================================
// VACCINATIONS
// ============================================================
function renderVaccinations() {
  const uid  = currentUser.id;
  const vacc = DB.vaccinations.filter(v => v.patient_id === uid).sort((a, b) => b.date.localeCompare(a.date));

  return `
  <div class="page-header">
    <div class="page-header-left"><h2>Vaccination Records</h2><p>Immunization history</p></div>
    <button class="btn btn-primary" onclick="openModal('add-vacc')">+ Add Record</button>
  </div>
  <div class="page-body">
    <div class="card">
      <div class="card-body" style="padding:0">
        ${vacc.length === 0 ? '<div class="empty-state"><p>No vaccination records yet</p></div>' : ''}
        <div class="table-wrap">
          <table>
            <thead><tr><th>Vaccine</th><th>Date</th><th>Dose</th><th>Facility</th><th></th></tr></thead>
            <tbody>${vacc.map(vc => `
              <tr>
                <td style="font-weight:500">${vc.name}</td>
                <td>${vc.date}</td>
                <td><span class="badge badge-blue">${vc.dose}</span></td>
                <td style="color:var(--text2)">${vc.facility || '—'}</td>
                <td><button class="btn btn-sm btn-danger" onclick="delItem('vaccinations',${vc.id})">Del</button></td>
              </tr>`).join('')}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>`;
}

// ============================================================
// DOCUMENTS
// ============================================================
function renderDocuments() {
  return `
  <div class="page-header">
    <div class="page-header-left"><h2>Documents & Files</h2><p>Manage lab results, prescriptions, and medical certificates</p></div>
  </div>
  <div class="page-body">
    <div class="card">
      <div class="card-body" style="text-align:center;padding:3rem">
        <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="var(--text3)" stroke-width="1.5" style="margin:0 auto 14px;display:block">
          <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/>
          <polyline points="14 2 14 8 20 8"/>
          <line x1="16" y1="13" x2="8" y2="13"/>
          <line x1="16" y1="17" x2="8" y2="17"/>
          <polyline points="10 9 9 9 8 9"/>
        </svg>
        <p style="color:var(--text2);margin-bottom:16px;font-size:14px">
          Upload lab results, X-rays, prescriptions, and certificates<br>
          <span style="font-size:12px;color:var(--text3)">Connect to a file storage backend (e.g. AWS S3, Cloudinary) to enable uploads</span>
        </p>
        <button class="btn btn-primary" onclick="alert('File upload: Connect to a backend storage service to enable this feature.')">Upload Document</button>
      </div>
    </div>
    <div class="grid-3" style="margin-top:1rem">
      ${[['Lab Results','🧪','No lab results uploaded'],['Prescriptions','📋','No prescriptions uploaded'],['X-Rays & Imaging','🩻','No images uploaded']].map(([t, e, d]) => `
        <div class="card">
          <div class="card-body" style="text-align:center;padding:1.5rem">
            <div style="font-size:28px;margin-bottom:8px">${e}</div>
            <div style="font-weight:600;font-size:13px;margin-bottom:4px">${t}</div>
            <div style="font-size:12px;color:var(--text3)">${d}</div>
          </div>
        </div>`).join('')}
    </div>
  </div>`;
}

// ============================================================
// HEALTH METRICS
// ============================================================
function renderHealth() {
  const uid = currentUser.id;
  const metrics = DB.health_metrics.filter(m => m.patient_id === uid).sort((a, b) => b.date.localeCompare(a.date));

  // Group metrics by type for charts
  const weightData = metrics.filter(m => m.type === 'weight').sort((a, b) => a.date.localeCompare(b.date));
  const bpData = metrics.filter(m => m.type === 'blood_pressure').sort((a, b) => a.date.localeCompare(b.date));
  const hrData = metrics.filter(m => m.type === 'heart_rate').sort((a, b) => a.date.localeCompare(b.date));

  return `
  <div class="page-header">
    <div class="page-header-left"><h2>Health Metrics</h2><p>Track your vital signs and health trends</p></div>
    <button class="btn btn-primary" onclick="openModal('add-metric')">+ Add Reading</button>
  </div>
  <div class="page-body">
    <!-- Quick Add Buttons -->
    <div class="grid-4" style="margin-bottom:1.25rem">
      <button class="quick-add-btn" onclick="quickAddMetric('weight')">
        <div class="quick-add-icon">⚖️</div>
        <div class="quick-add-text">Weight</div>
      </button>
      <button class="quick-add-btn" onclick="quickAddMetric('blood_pressure')">
        <div class="quick-add-icon">🩸</div>
        <div class="quick-add-text">Blood Pressure</div>
      </button>
      <button class="quick-add-btn" onclick="quickAddMetric('heart_rate')">
        <div class="quick-add-icon">❤️</div>
        <div class="quick-add-text">Heart Rate</div>
      </button>
      <button class="quick-add-btn" onclick="quickAddMetric('temperature')">
        <div class="quick-add-icon">🌡️</div>
        <div class="quick-add-text">Temperature</div>
      </button>
    </div>

    <!-- Charts Section -->
    <div class="grid-2" style="margin-bottom:1.25rem">
      <!-- Weight Chart -->
      <div class="card">
        <div class="card-header"><h3>Weight Trend</h3></div>
        <div class="card-body">
          <canvas id="weightChart" width="400" height="200"></canvas>
        </div>
      </div>

      <!-- Blood Pressure Chart -->
      <div class="card">
        <div class="card-header"><h3>Blood Pressure Trend</h3></div>
        <div class="card-body">
          <canvas id="bpChart" width="400" height="200"></canvas>
        </div>
      </div>
    </div>

    <!-- Heart Rate Chart -->
    <div class="card" style="margin-bottom:1.25rem">
      <div class="card-header"><h3>Heart Rate Trend</h3></div>
      <div class="card-body">
        <canvas id="hrChart" width="400" height="200"></canvas>
      </div>
    </div>

    <!-- Recent Readings Table -->
    <div class="card">
      <div class="card-header"><h3>Recent Readings</h3></div>
      <div class="card-body" style="padding:0">
        ${metrics.length === 0 ? '<div class="empty-state"><p>No health metrics recorded yet</p></div>' : ''}
        <div class="table-wrap">
          <table>
            <thead><tr><th>Type</th><th>Value</th><th>Date</th><th>Notes</th><th></th></tr></thead>
            <tbody>${metrics.slice(0, 20).map(m => `
              <tr>
                <td style="font-weight:500">${formatMetricType(m.type)}</td>
                <td>${formatMetricValue(m.type, m.value)}</td>
                <td>${m.date}</td>
                <td style="color:var(--text2);font-size:12px">${m.notes || '—'}</td>
                <td><button class="btn btn-sm btn-danger" onclick="delItem('health_metrics',${m.id})">Del</button></td>
              </tr>`).join('')}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>`;
}

// Initialize charts after render
function initHealthCharts() {
  if (typeof Chart === 'undefined') {
    console.warn('Chart.js not loaded');
    return;
  }
  
  const uid = currentUser.id;
  const metrics = DB.health_metrics.filter(m => m.patient_id === uid);

  // Weight Chart
  const weightData = metrics.filter(m => m.type === 'weight').sort((a, b) => a.date.localeCompare(b.date));
  if (weightData.length > 0 && document.getElementById('weightChart')) {
    new Chart(document.getElementById('weightChart'), {
      type: 'line',
      data: {
        labels: weightData.map(m => m.date),
        datasets: [{
          label: 'Weight (kg)',
          data: weightData.map(m => m.value),
          borderColor: '#4CAF50',
          backgroundColor: 'rgba(76, 175, 80, 0.1)',
          tension: 0.4
        }]
      },
      options: {
        responsive: true,
        plugins: { legend: { display: false } },
        scales: { y: { beginAtZero: false } }
      }
    });
  }

  // Blood Pressure Chart
  const bpData = metrics.filter(m => m.type === 'blood_pressure').sort((a, b) => a.date.localeCompare(b.date));
  if (bpData.length > 0 && document.getElementById('bpChart')) {
    const parseBP = (val) => {
      const parts = String(val).split('/');
      return parts.length === 2 ? [parseInt(parts[0]), parseInt(parts[1])] : [parseInt(val), parseInt(val)];
    };
    
    new Chart(document.getElementById('bpChart'), {
      type: 'line',
      data: {
        labels: bpData.map(m => m.date),
        datasets: [{
          label: 'Systolic',
          data: bpData.map(m => parseBP(m.value)[0]),
          borderColor: '#2196F3',
          backgroundColor: 'rgba(33, 150, 243, 0.1)',
          tension: 0.4
        }, {
          label: 'Diastolic',
          data: bpData.map(m => parseBP(m.value)[1]),
          borderColor: '#FF9800',
          backgroundColor: 'rgba(255, 152, 0, 0.1)',
          tension: 0.4
        }]
      },
      options: {
        responsive: true,
        plugins: { legend: { position: 'bottom' } },
        scales: { y: { beginAtZero: false } }
      }
    });
  }

  // Heart Rate Chart
  const hrData = metrics.filter(m => m.type === 'heart_rate').sort((a, b) => a.date.localeCompare(b.date));
  if (hrData.length > 0 && document.getElementById('hrChart')) {
    new Chart(document.getElementById('hrChart'), {
      type: 'line',
      data: {
        labels: hrData.map(m => m.date),
        datasets: [{
          label: 'Heart Rate (bpm)',
          data: hrData.map(m => m.value),
          borderColor: '#E91E63',
          backgroundColor: 'rgba(233, 30, 99, 0.1)',
          tension: 0.4
        }]
      },
      options: {
        responsive: true,
        plugins: { legend: { display: false } },
        scales: { y: { beginAtZero: false } }
      }
    });
  }
}

function quickAddMetric(type) {
  const value = prompt(`Enter ${formatMetricType(type)} value:`);
  if (!value || isNaN(parseFloat(value))) return;

  DB.health_metrics.push({
    id: DB.nextId++,
    patient_id: currentUser.id,
    type: type,
    value: parseFloat(value),
    date: new Date().toISOString().split('T')[0],
    notes: ''
  });
  
  navigate('health');
}

// ============================================================
// LAB RESULTS
// ============================================================
function renderLabResults() {
  const uid = currentUser.id;
  const labs = DB.lab_results.filter(l => l.patient_id === uid).sort((a, b) => b.date.localeCompare(a.date));

  return `
  <div class="page-header">
    <div class="page-header-left"><h2>Lab Results</h2><p>Manage your test results and reports</p></div>
    <button class="btn btn-primary" onclick="openModal('add-lab')">+ Add Lab Result</button>
  </div>
  <div class="page-body">
    ${labs.length === 0 ? '<div class="empty-state"><p>No lab results recorded yet</p></div>' : ''}
    <div style="display:grid;gap:10px">
      ${labs.map(lab => `
        <div class="card">
          <div class="card-body" style="display:flex;align-items:flex-start;justify-content:space-between;gap:12px">
            <div style="flex:1">
              <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap;margin-bottom:4px">
                <span style="font-size:14px;font-weight:600">🧪 ${lab.test_name}</span>
                <span class="badge badge-blue">${lab.date}</span>
              </div>
              <div style="font-size:13px;color:var(--text2);margin-bottom:8px">${lab.facility}</div>
              <div style="font-size:13px;color:var(--text);margin-bottom:4px"><strong>Result:</strong> ${lab.results}</div>
              ${lab.notes ? `<div style="font-size:12px;color:var(--text3)">${lab.notes}</div>` : ''}
            </div>
            <div style="display:flex;gap:4px;flex-shrink:0">
              <button class="btn btn-sm" onclick="openModal('edit-lab-${lab.id}')">Edit</button>
              <button class="btn btn-sm btn-danger" onclick="delItem('lab_results',${lab.id})">Del</button>
            </div>
          </div>
        </div>`).join('')}
    </div>
  </div>`;
}

function formatMetricType(type) {
  const types = {
    weight: 'Weight',
    blood_pressure: 'Blood Pressure',
    heart_rate: 'Heart Rate',
    temperature: 'Temperature',
    blood_sugar: 'Blood Sugar',
    oxygen_saturation: 'Oxygen Saturation'
  };
  return types[type] || type;
}

function formatMetricValue(type, value) {
  switch(type) {
    case 'weight': return `${value} kg`;
    case 'blood_pressure': return `${value} mmHg`;
    case 'heart_rate': return `${value} bpm`;
    case 'temperature': return `${value}°C`;
    case 'blood_sugar': return `${value} mg/dL`;
    case 'oxygen_saturation': return `${value}%`;
    default: return value;
  }
}

// ============================================================
// APPOINTMENTS
// ============================================================
function renderAppointments() {
  const uid = currentUser.id;
  const appointments = DB.appointments.filter(a => a.patient_id === uid).sort((a, b) => new Date(a.date + ' ' + a.time) - new Date(b.date + ' ' + b.time));
  const upcoming = appointments.filter(a => new Date(a.date + ' ' + a.time) > new Date());
  const past = appointments.filter(a => new Date(a.date + ' ' + a.time) <= new Date());

  return `
  <div class="page-header">
    <div class="page-header-left"><h2>Appointments</h2><p>Schedule and manage your medical appointments</p></div>
    <button class="btn btn-primary" onclick="openModal('add-appointment')">+ Schedule Appointment</button>
  </div>
  <div class="page-body">
    ${upcoming.length > 0 ? `
      <div class="card" style="margin-bottom:1.25rem">
        <div class="card-header"><h3>Upcoming Appointments</h3><span class="badge badge-blue">${upcoming.length} scheduled</span></div>
        <div class="card-body" style="padding:0">
          ${upcoming.map(apt => `
            <div style="display:flex;justify-content:space-between;align-items:center;padding:12px 1.25rem;border-bottom:1px solid var(--border)">
              <div>
                <div style="font-size:14px;font-weight:600">${apt.doctor} - ${apt.specialty}</div>
                <div style="font-size:12px;color:var(--text2)">${apt.hospital} • ${apt.date} at ${apt.time}</div>
                <div style="font-size:12px;color:var(--text3)">${apt.purpose}</div>
              </div>
              <div style="display:flex;gap:6px">
                <button class="btn btn-sm" onclick="openModal('edit-appointment-${apt.id}')">${iconEdit()}</button>
                <button class="btn btn-sm btn-danger" onclick="delItem('appointments',${apt.id})">${iconTrash()}</button>
              </div>
            </div>`).join('')}
        </div>
      </div>` : ''}

    <div class="card">
      <div class="card-header"><h3>Past Appointments</h3></div>
      <div class="card-body" style="padding:0">
        ${past.length === 0 ? '<div class="empty-state" style="padding:1.5rem"><p>No past appointments</p></div>' : ''}
        ${past.map(apt => `
          <div style="display:flex;justify-content:space-between;align-items:center;padding:12px 1.25rem;border-bottom:1px solid var(--border);opacity:0.8">
            <div>
              <div style="font-size:14px;font-weight:600">${apt.doctor} - ${apt.specialty}</div>
              <div style="font-size:12px;color:var(--text2)">${apt.hospital} • ${apt.date} at ${apt.time}</div>
              <div style="font-size:12px;color:var(--text3)">${apt.purpose}</div>
            </div>
            <div style="display:flex;gap:6px">
              <button class="btn btn-sm" onclick="openModal('edit-appointment-${apt.id}')">${iconEdit()}</button>
              <button class="btn btn-sm btn-danger" onclick="delItem('appointments',${apt.id})">${iconTrash()}</button>
            </div>
          </div>`).join('')}
      </div>
    </div>
  </div>`;
}

// ============================================================
// SYMPTOMS
// ============================================================
function renderSymptoms() {
  const uid = currentUser.id;
  const symptoms = DB.symptoms.filter(s => s.patient_id === uid).sort((a, b) => b.date.localeCompare(a.date));
  const today = new Date().toISOString().split('T')[0];
  const todaySymptoms = symptoms.filter(s => s.date === today);

  return `
  <div class="page-header">
    <div class="page-header-left"><h2>Symptom Tracker</h2><p>Log and monitor your symptoms over time</p></div>
    <button class="btn btn-primary" onclick="openModal('add-symptom')">+ Log Symptom</button>
  </div>
  <div class="page-body">
    ${todaySymptoms.length > 0 ? `
      <div class="card" style="margin-bottom:1.25rem">
        <div class="card-header"><h3>Today's Symptoms</h3><span class="badge badge-amber">${todaySymptoms.length} logged</span></div>
        <div class="card-body" style="padding:0">
          ${todaySymptoms.map(sym => `
            <div style="display:flex;justify-content:space-between;align-items:center;padding:12px 1.25rem;border-bottom:1px solid var(--border)">
              <div>
                <div style="font-size:14px;font-weight:600">${sym.symptom}</div>
                <div style="font-size:12px;color:var(--text2)">Severity: ${sym.severity}/10 • Duration: ${sym.duration}</div>
                ${sym.notes ? `<div style="font-size:12px;color:var(--text3)">${sym.notes}</div>` : ''}
              </div>
              <div style="display:flex;gap:6px">
                <button class="btn btn-sm" onclick="openModal('edit-symptom-${sym.id}')">${iconEdit()}</button>
                <button class="btn btn-sm btn-danger" onclick="delItem('symptoms',${sym.id})">${iconTrash()}</button>
              </div>
            </div>`).join('')}
        </div>
      </div>` : ''}

    <div class="card">
      <div class="card-header"><h3>Symptom History</h3></div>
      <div class="card-body" style="padding:0">
        ${symptoms.length === 0 ? '<div class="empty-state" style="padding:1.5rem"><p>No symptoms logged yet</p></div>' : ''}
        ${symptoms.map(sym => `
          <div style="display:flex;justify-content:space-between;align-items:center;padding:12px 1.25rem;border-bottom:1px solid var(--border)">
            <div>
              <div style="font-size:14px;font-weight:600">${sym.symptom}</div>
              <div style="font-size:12px;color:var(--text2)">${sym.date} • Severity: ${sym.severity}/10 • Duration: ${sym.duration}</div>
              ${sym.notes ? `<div style="font-size:12px;color:var(--text3)">${sym.notes}</div>` : ''}
            </div>
            <div style="display:flex;gap:6px">
              <button class="btn btn-sm" onclick="openModal('edit-symptom-${sym.id}')">${iconEdit()}</button>
              <button class="btn btn-sm btn-danger" onclick="delItem('symptoms',${sym.id})">${iconTrash()}</button>
            </div>
          </div>`).join('')}
      </div>
    </div>
  </div>`;
}

// ============================================================
// HEALTH GOALS
// ============================================================
function renderGoals() {
  const uid = currentUser.id;
  const goals = DB.healthGoals.filter(g => g.patient_id === uid);
  const activeGoals = goals.filter(g => g.status === 'active');
  const completedGoals = goals.filter(g => g.status === 'completed');

  return `
  <div class="page-header">
    <div class="page-header-left"><h2>Health Goals</h2><p>Set and track your health objectives</p></div>
    <button class="btn btn-primary" onclick="openModal('add-goal')">+ Set Goal</button>
  </div>
  <div class="page-body">
    ${activeGoals.length > 0 ? `
      <div class="card" style="margin-bottom:1.25rem">
        <div class="card-header"><h3>Active Goals</h3><span class="badge badge-green">${activeGoals.length} in progress</span></div>
        <div class="card-body" style="padding:0">
          ${activeGoals.map(goal => `
            <div style="padding:16px 1.25rem;border-bottom:1px solid var(--border)">
              <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:8px">
                <div style="font-size:14px;font-weight:600">${goal.title}</div>
                <div style="display:flex;gap:6px">
                  <button class="btn btn-sm" onclick="updateGoalStatus(${goal.id}, 'completed')">${iconCheck()}</button>
                  <button class="btn btn-sm" onclick="openModal('edit-goal-${goal.id}')">${iconEdit()}</button>
                  <button class="btn btn-sm btn-danger" onclick="delItem('healthGoals',${goal.id})">${iconTrash()}</button>
                </div>
              </div>
              <div style="font-size:12px;color:var(--text2);margin-bottom:8px">${goal.description}</div>
              <div style="display:flex;gap:12px">
                <div style="font-size:11px;color:var(--text3)">Target: ${goal.target_date}</div>
                <div style="font-size:11px;color:var(--text3)">Category: ${goal.category}</div>
              </div>
              ${goal.progress !== undefined ? `
                <div style="margin-top:8px">
                  <div style="display:flex;justify-content:space-between;font-size:11px;color:var(--text2);margin-bottom:4px">
                    <span>Progress</span>
                    <span>${goal.progress}%</span>
                  </div>
                  <div style="width:100%;height:6px;background:var(--border);border-radius:3px">
                    <div style="width:${goal.progress}%;height:100%;background:var(--primary);border-radius:3px"></div>
                  </div>
                </div>` : ''}
            </div>`).join('')}
        </div>
      </div>` : ''}

    <div class="card">
      <div class="card-header"><h3>Completed Goals</h3><span class="badge badge-purple">${completedGoals.length} achieved</span></div>
      <div class="card-body" style="padding:0">
        ${completedGoals.length === 0 ? '<div class="empty-state" style="padding:1.5rem"><p>No completed goals yet</p></div>' : ''}
        ${completedGoals.map(goal => `
          <div style="padding:16px 1.25rem;border-bottom:1px solid var(--border);opacity:0.8">
            <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:8px">
              <div style="font-size:14px;font-weight:600">${goal.title}</div>
              <div style="display:flex;gap:6px">
                <button class="btn btn-sm" onclick="openModal('edit-goal-${goal.id}')">${iconEdit()}</button>
                <button class="btn btn-sm btn-danger" onclick="delItem('healthGoals',${goal.id})">${iconTrash()}</button>
              </div>
            </div>
            <div style="font-size:12px;color:var(--text2);margin-bottom:8px">${goal.description}</div>
            <div style="display:flex;gap:12px">
              <div style="font-size:11px;color:var(--text3)">Completed: ${goal.completed_date || goal.target_date}</div>
              <div style="font-size:11px;color:var(--text3)">Category: ${goal.category}</div>
            </div>
          </div>`).join('')}
      </div>
    </div>
  </div>`;
}

// ============================================================
// FAMILY HEALTH
// ============================================================
function renderFamily() {
  const uid = currentUser.id;
  const familyMembers = DB.familyMembers.filter(f => f.patient_id === uid);

  return `
  <div class="page-header">
    <div class="page-header-left"><h2>Family Health</h2><p>Track health information for your family members</p></div>
    <button class="btn btn-primary" onclick="openModal('add-family')">+ Add Family Member</button>
  </div>
  <div class="page-body">
    ${familyMembers.length === 0 ? '<div class="empty-state"><p>No family members added yet</p></div>' : ''}
    <div class="grid-2" style="gap:1rem">
      ${familyMembers.map(member => `
        <div class="card">
          <div class="card-header">
            <h3>${member.name}</h3>
            <div style="display:flex;gap:6px">
              <button class="btn btn-sm" onclick="openModal('edit-family-${member.id}')">${iconEdit()}</button>
              <button class="btn btn-sm btn-danger" onclick="delItem('familyMembers',${member.id})">${iconTrash()}</button>
            </div>
          </div>
          <div class="card-body">
            <div style="display:grid;gap:8px;font-size:13px">
              <div><strong>Relationship:</strong> ${member.relationship}</div>
              <div><strong>Age:</strong> ${member.age || 'Not specified'}</div>
              <div><strong>Blood Type:</strong> ${member.blood_type || 'Not specified'}</div>
              ${member.conditions ? `<div><strong>Medical Conditions:</strong> ${member.conditions}</div>` : ''}
              ${member.allergies ? `<div><strong>Allergies:</strong> ${member.allergies}</div>` : ''}
              ${member.medications ? `<div><strong>Medications:</strong> ${member.medications}</div>` : ''}
              ${member.notes ? `<div><strong>Notes:</strong> ${member.notes}</div>` : ''}
            </div>
          </div>
        </div>`).join('')}
    </div>
  </div>`;
}

// ============================================================
// HEALTH EDUCATION
// ============================================================
function renderEducation() {
  const uid = currentUser.id;
  const articles = DB.healthArticles || [];
  const userArticles = articles.filter(a => !a.patient_id || a.patient_id === uid);

  return `
  <div class="page-header">
    <div class="page-header-left"><h2>Health Education</h2><p>Learn about health topics and wellness</p></div>
  </div>
  <div class="page-body">
    <div class="grid-3" style="margin-bottom:1.25rem;gap:1rem">
      <div class="card">
        <div class="card-body" style="text-align:center;padding:2rem">
          <div style="font-size:32px;margin-bottom:8px">📚</div>
          <div style="font-weight:600;margin-bottom:4px">Health Articles</div>
          <div style="font-size:12px;color:var(--text3)">Read about various health topics</div>
        </div>
      </div>
      <div class="card">
        <div class="card-body" style="text-align:center;padding:2rem">
          <div style="font-size:32px;margin-bottom:8px">🎯</div>
          <div style="font-weight:600;margin-bottom:4px">Wellness Tips</div>
          <div style="font-size:12px;color:var(--text3)">Daily health and wellness advice</div>
        </div>
      </div>
      <div class="card">
        <div class="card-body" style="text-align:center;padding:2rem">
          <div style="font-size:32px;margin-bottom:8px">🔔</div>
          <div style="font-weight:600;margin-bottom:4px">Health Reminders</div>
          <div style="font-size:12px;color:var(--text3)">Medication and appointment alerts</div>
        </div>
      </div>
    </div>

    <div class="card">
      <div class="card-header"><h3>Featured Articles</h3></div>
      <div class="card-body" style="padding:0">
        ${userArticles.length === 0 ? '<div class="empty-state" style="padding:1.5rem"><p>No articles available yet</p></div>' : ''}
        ${userArticles.slice(0, 10).map(article => `
          <div style="display:flex;padding:16px 1.25rem;border-bottom:1px solid var(--border)">
            <div style="flex:1">
              <div style="font-size:14px;font-weight:600;margin-bottom:4px">${article.title}</div>
              <div style="font-size:12px;color:var(--text2);margin-bottom:8px">${article.category} • ${article.read_time || '5 min read'}</div>
              <div style="font-size:13px;color:var(--text)">${article.excerpt || article.content?.substring(0, 150) + '...'}</div>
            </div>
            <div style="margin-left:16px">
              <button class="btn btn-sm" onclick="readArticle(${article.id})">Read</button>
            </div>
          </div>`).join('')}
      </div>
    </div>
  </div>`;
}

function updateGoalStatus(goalId, status) {
  const goal = DB.healthGoals.find(g => g.id === goalId);
  if (goal) {
    goal.status = status;
    if (status === 'completed') {
      goal.completed_date = new Date().toISOString().split('T')[0];
    }
    render();
  }
}

function readArticle(articleId) {
  const article = DB.healthArticles.find(a => a.id === articleId);
  if (article) {
    openModal('read-article', { article });
  }
}
