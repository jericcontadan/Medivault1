/**
 * MediVault — modals.js
 * Modal open/close logic and modal template renderers.
 */

// List of Philippine hospitals for dropdowns
const PHILIPPINE_HOSPITALS = [
  "Philippine General Hospital",
  "St. Luke's Medical Center",
  "Makati Medical Center",
  "The Medical City",
  "Capitol Medical Center",
  "Philippine Heart Center",
  "Healthway Clinic",
  "Asian Hospital and Medical Center",
  "De Los Santos Medical Center",
  "Manila Doctors Hospital"
];

// ============================================================
// MODAL CONTROLLER
// ============================================================
function openModal(type)  { modal = type; render(); }
function closeModal()     { modal = null; render(); }

function renderModal() {
  if (modal.startsWith('add-hist-') || modal.startsWith('edit-hist-')) {
    const isEdit = modal.startsWith('edit-hist-');
    const htype  = isEdit ? null : modal.replace('add-hist-', '');
    const item   = isEdit ? DB.medical_history.find(x => x.id === parseInt(modal.replace('edit-hist-', ''))) : null;
    const type   = isEdit ? item.type : htype;
    return histModal(type, item);
  }
  if (modal === 'add-visit' || modal.startsWith('edit-visit-')) {
    const item = modal.startsWith('edit-visit-')
      ? DB.visits.find(x => x.id === parseInt(modal.split('-')[2]))
      : null;
    return visitModal(item);
  }
  if (modal === 'add-med' || modal.startsWith('edit-med-')) {
    const item = modal.startsWith('edit-med-')
      ? DB.medications.find(x => x.id === parseInt(modal.split('-')[2]))
      : null;
    return medModal(item);
  }
  if (modal === 'add-vacc') return vaccModal();
  if (modal === 'add-lab' || modal.startsWith('edit-lab-')) {
    const item = modal.startsWith('edit-lab-')
      ? DB.lab_results.find(x => x.id === parseInt(modal.split('-')[2]))
      : null;
    return labModal(item);
  }
  if (modal === 'add-metric' || modal === 'metric') return metricModal();
  if (modal.startsWith('add-consult-') || modal.startsWith('edit-consult-')) {
    const isEdit = modal.startsWith('edit-consult-');
    const item   = isEdit ? DB.consultations.find(x => x.id === parseInt(modal.split('-')[2])) : null;
    const pid    = isEdit ? item.patient_id : parseInt(modal.split('-')[2]);
    return consultModal(item, pid);
  }
  if (modal === 'add-appointment' || modal.startsWith('edit-appointment-')) {
    const item = modal.startsWith('edit-appointment-')
      ? DB.appointments.find(x => x.id === parseInt(modal.split('-')[2]))
      : null;
    return appointmentModal(item);
  }
  if (modal === 'add-symptom' || modal.startsWith('edit-symptom-')) {
    const item = modal.startsWith('edit-symptom-')
      ? DB.symptoms.find(x => x.id === parseInt(modal.split('-')[2]))
      : null;
    return symptomModal(item);
  }
  if (modal === 'add-goal' || modal.startsWith('edit-goal-')) {
    const item = modal.startsWith('edit-goal-')
      ? DB.healthGoals.find(x => x.id === parseInt(modal.split('-')[2]))
      : null;
    return goalModal(item);
  }
  if (modal === 'add-family' || modal.startsWith('edit-family-')) {
    const item = modal.startsWith('edit-family-')
      ? DB.familyMembers.find(x => x.id === parseInt(modal.split('-')[2]))
      : null;
    return familyModal(item);
  }
  if (modal.startsWith('read-article-')) {
    const articleId = parseInt(modal.split('-')[2]);
    const article = DB.healthArticles.find(a => a.id === articleId);
    return articleModal(article);
  }
  return '';
}

// ============================================================
// MEDICAL HISTORY MODAL
// ============================================================
function histModal(htype, item) {
  const titles = {
    illness: 'Illness / Hospitalization',
    allergy: 'Allergy',
    family:  'Family Medical History',
  };
  return `
    <div class="modal-overlay" onclick="if(event.target===this)closeModal()">
      <div class="modal">
        <div class="modal-header">
          <h3>${item ? 'Edit' : 'Add'} ${titles[htype]}</h3>
          <button class="close-btn" onclick="closeModal()">✕</button>
        </div>
        <div class="modal-body">
          <div class="form-group">
            <label>Title / Name</label>
            <input id="h-title" value="${item ? item.title : ''}">
          </div>

          ${htype === 'allergy' ? `
          <div class="form-row">
            <div class="form-group">
              <label>Category</label>
              <select id="h-cat">
                <option ${item && item.category === 'Medicine'     ? 'selected' : ''}>Medicine</option>
                <option ${item && item.category === 'Food'         ? 'selected' : ''}>Food</option>
                <option ${item && item.category === 'Environmental'? 'selected' : ''}>Environmental</option>
                <option ${item && item.category === 'Other'        ? 'selected' : ''}>Other</option>
              </select>
            </div>
            <div class="form-group">
              <label>Severity</label>
              <select id="h-sev">
                <option ${item && item.severity === 'Mild'    ? 'selected' : ''}>Mild</option>
                <option ${item && item.severity === 'Moderate'? 'selected' : ''}>Moderate</option>
                <option ${item && item.severity === 'Severe'  ? 'selected' : ''}>Severe</option>
              </select>
            </div>
          </div>` : ''}

          ${htype === 'family' ? `
          <div class="form-group">
            <label>Relation</label>
            <input id="h-rel" value="${item && item.relation ? item.relation : ''}" placeholder="e.g. Father, Mother">
          </div>` : ''}

          ${htype === 'illness' ? `
          <div class="form-group">
            <label>Date</label>
            <input id="h-date" type="date" value="${item && item.date ? item.date : ''}">
          </div>` : ''}

          <div class="form-group">
            <label>Notes</label>
            <textarea id="h-notes">${item ? item.notes : ''}</textarea>
          </div>
        </div>
        <div class="modal-footer">
          <button class="btn" onclick="closeModal()">Cancel</button>
          <button id="save-hist-btn" class="btn btn-primary" onclick="saveHist('${htype}', ${item ? item.id : 'null'})">Save</button>
        </div>
      </div>
    </div>`;
}

function saveHist(htype, id) {
  // Add loading state
  setButtonLoading('save-hist-btn', true);

  const entry = {
    patient_id: currentUser.id,
    type:       htype,
    title:      v('h-title'),
    notes:      v('h-notes'),
    date:       htype === 'illness' ? v('h-date') : null,
    category:   htype === 'allergy' ? document.getElementById('h-cat').value : null,
    severity:   htype === 'allergy' ? document.getElementById('h-sev').value : null,
    relation:   htype === 'family'  ? v('h-rel') : null,
  };

  // Simulate processing delay
  setTimeout(() => {
    if (id !== 'null' && id) {
      const i = DB.medical_history.findIndex(x => x.id === parseInt(id));
      DB.medical_history[i] = { ...DB.medical_history[i], ...entry };
    } else {
      DB.medical_history.push({ ...entry, id: getNextId() });
    }
    showToast(`${htype.charAt(0).toUpperCase() + htype.slice(1)} ${id !== 'null' && id ? 'updated' : 'added'} successfully!`, 'success');
    closeModal();
  }, 500);
}

// ============================================================
// VISIT MODAL
// ============================================================
function visitModal(item) {
  return `
    <div class="modal-overlay" onclick="if(event.target===this)closeModal()">
      <div class="modal">
        <div class="modal-header">
          <h3>${item ? 'Edit' : 'Log'} Visit</h3>
          <button class="close-btn" onclick="closeModal()">✕</button>
        </div>
        <div class="modal-body">
          <div class="form-group">
            <label>Date</label>
            <input id="vt-date" type="date" value="${item ? item.date : new Date().toISOString().split('T')[0]}">
          </div>
          <div class="form-group">
            <label>Reason for Visit</label>
            <input id="vt-reason" value="${item ? item.reason : ''}">
          </div>
          <div class="form-row">
            <div class="form-group"><label>Doctor</label><input id="vt-doc"  value="${item ? item.doctor   : ''}"></div>
            <div class="form-group"><label>Hospital / Clinic</label><select id="vt-hosp">${PHILIPPINE_HOSPITALS.map(h => `<option value="${h}" ${item && item.hospital === h ? 'selected' : ''}>${h}</option>`).join('')}</select></div>
          </div>
          <div class="form-group">
            <label>Notes</label>
            <textarea id="vt-notes">${item ? item.notes : ''}</textarea>
          </div>
        </div>
        <div class="modal-footer">
          <button class="btn" onclick="closeModal()">Cancel</button>
          <button class="btn btn-primary" onclick="saveVisit(${item ? item.id : 'null'})">Save</button>
        </div>
      </div>
    </div>`;
}

function saveVisit(id) {
  const entry = {
    patient_id: currentUser.id,
    date:    v('vt-date'),
    reason:  v('vt-reason'),
    doctor:  v('vt-doc'),
    hospital:v('vt-hosp'),
    notes:   v('vt-notes'),
  };
  if (id !== 'null' && id) {
    const i = DB.visits.findIndex(x => x.id === parseInt(id));
    DB.visits[i] = { ...DB.visits[i], ...entry };
  } else {
    DB.visits.push({ ...entry, id: getNextId() });
  }
  closeModal();
}

// ============================================================
// MEDICATION MODAL
// ============================================================
function medModal(item) {
  return `
    <div class="modal-overlay" onclick="if(event.target===this)closeModal()">
      <div class="modal">
        <div class="modal-header">
          <h3>${item ? 'Edit' : 'Add'} Medication</h3>
          <button class="close-btn" onclick="closeModal()">✕</button>
        </div>
        <div class="modal-body">
          <div class="form-group">
            <label>Medication Name</label>
            <input id="md-name" value="${item ? item.name : ''}">
          </div>
          <div class="form-row">
            <div class="form-group"><label>Dosage</label><input id="md-dose" value="${item ? item.dosage : ''}"    placeholder="e.g. 500mg"></div>
            <div class="form-group"><label>Frequency</label><input id="md-freq" value="${item ? item.frequency : ''}" placeholder="e.g. Twice daily"></div>
          </div>
          <div class="form-row">
            <div class="form-group"><label>Start Date</label><input id="md-start" type="date" value="${item ? item.start : ''}"></div>
            <div class="form-group"><label>End Date (optional)</label><input id="md-end" type="date" value="${item && item.end ? item.end : ''}"></div>
          </div>
          <div class="form-row">
            <div class="form-group"><label>Expiry Date</label><input id="md-expiry" type="date" value="${item && item.expiry ? item.expiry : ''}"></div>
            <div class="form-group">
              <label>Status</label>
              <select id="md-cur">
                <option value="1" ${!item || item.current ? 'selected' : ''}>Currently Taking</option>
                <option value="0" ${item && !item.current ? 'selected' : ''}>Completed / Past</option>
              </select>
            </div>
          </div>
          <div class="form-group">
            <label>Notes (optional)</label>
            <textarea id="md-notes">${item && item.notes ? item.notes : ''}</textarea>
          </div>
        </div>
        <div class="modal-footer">
          <button class="btn" onclick="closeModal()">Cancel</button>
          <button class="btn btn-primary" onclick="saveMed(${item ? item.id : 'null'})">Save</button>
        </div>
      </div>
    </div>`;
}

function saveMed(id) {
  const entry = {
    patient_id: currentUser.id,
    name:      v('md-name'),
    dosage:    v('md-dose'),
    frequency: v('md-freq'),
    start:     v('md-start'),
    end:       v('md-end'),
    current:   document.getElementById('md-cur').value === '1',
    expiry:    v('md-expiry'),
    notes:     v('md-notes'),
  };
  if (id !== 'null' && id) {
    const i = DB.medications.findIndex(x => x.id === parseInt(id));
    DB.medications[i] = { ...DB.medications[i], ...entry };
  } else {
    DB.medications.push({ ...entry, id: getNextId() });
  }
  closeModal();
}

// ============================================================
// VACCINATION MODAL
// ============================================================
function vaccModal() {
  return `
    <div class="modal-overlay" onclick="if(event.target===this)closeModal()">
      <div class="modal">
        <div class="modal-header">
          <h3>Add Vaccination Record</h3>
          <button class="close-btn" onclick="closeModal()">✕</button>
        </div>
        <div class="modal-body">
          <div class="form-group"><label>Vaccine Name</label><input id="vc-name"></div>
          <div class="form-row">
            <div class="form-group"><label>Date Administered</label><input id="vc-date" type="date"></div>
            <div class="form-group"><label>Dose</label><input id="vc-dose" placeholder="e.g. Dose 1/2, Booster, Annual"></div>
          </div>
          <div class="form-group"><label>Facility</label><select id="vc-fac">${PHILIPPINE_HOSPITALS.map(h => `<option value="${h}">${h}</option>`).join('')}</select></div>
        </div>
        <div class="modal-footer">
          <button class="btn" onclick="closeModal()">Cancel</button>
          <button class="btn btn-primary" onclick="saveVacc()">Save</button>
        </div>
      </div>
    </div>`;
}

function saveVacc() {
  DB.vaccinations.push({
    id:         getNextId(),
    patient_id: currentUser.id,
    name:       v('vc-name'),
    date:       v('vc-date'),
    dose:       v('vc-dose'),
    facility:   v('vc-fac'),
  });
  closeModal();
}

// ============================================================
// LAB RESULTS MODAL
// ============================================================
function labModal(item) {
  return `
    <div class="modal-overlay" onclick="if(event.target===this)closeModal()">
      <div class="modal">
        <div class="modal-header">
          <h3>${item ? 'Edit' : 'Add'} Lab Result</h3>
          <button class="close-btn" onclick="closeModal()">✕</button>
        </div>
        <div class="modal-body">
          <div class="form-group">
            <label>Test Name</label>
            <input id="lr-name" value="${item ? item.test_name : ''}" placeholder="e.g. Complete Blood Count, Cholesterol Panel">
          </div>
          <div class="form-row">
            <div class="form-group"><label>Test Date</label><input id="lr-date" type="date" value="${item ? item.date : ''}"></div>
            <div class="form-group"><label>Facility</label><select id="lr-fac">${PHILIPPINE_HOSPITALS.map(h => `<option value="${h}" ${item && item.facility === h ? 'selected' : ''}>${h}</option>`).join('')}</select></div>
          </div>
          <div class="form-group">
            <label>Results</label>
            <textarea id="lr-results" placeholder="e.g. Normal range, 195 mg/dL">${item ? item.results : ''}</textarea>
          </div>
          <div class="form-group">
            <label>Notes (optional)</label>
            <textarea id="lr-notes">${item ? item.notes : ''}</textarea>
          </div>
        </div>
        <div class="modal-footer">
          <button class="btn" onclick="closeModal()">Cancel</button>
          <button class="btn btn-primary" onclick="saveLab(${item ? item.id : 'null'})">Save</button>
        </div>
      </div>
    </div>`;
}

function saveLab(id) {
  const entry = {
    patient_id: currentUser.id,
    test_name: v('lr-name'),
    date:      v('lr-date'),
    facility:  v('lr-fac'),
    results:   v('lr-results'),
    notes:     v('lr-notes'),
  };
  if (id !== 'null' && id) {
    const i = DB.lab_results.findIndex(x => x.id === parseInt(id));
    DB.lab_results[i] = { ...DB.lab_results[i], ...entry };
  } else {
    DB.lab_results.push({ ...entry, id: getNextId() });
  }
  closeModal();
}

// ============================================================
// CONSULTATION MODAL
// ============================================================
function consultModal(item, pid) {
  const pt = DB.users.find(u => u.id === pid);
  return `
    <div class="modal-overlay" onclick="if(event.target===this)closeModal()">
      <div class="modal">
        <div class="modal-header">
          <h3>${item ? 'Edit' : 'New'} Consultation — ${pt ? pt.name : ''}</h3>
          <button class="close-btn" onclick="closeModal()">✕</button>
        </div>
        <div class="modal-body">
          <div class="form-row">
            <div class="form-group">
              <label>Date</label>
              <input id="cs-date" type="date" value="${item ? item.date : new Date().toISOString().split('T')[0]}">
            </div>
            <div class="form-group">
              <label>Follow-up Date</label>
              <input id="cs-fu" type="date" value="${item && item.follow_up ? item.follow_up : ''}">
            </div>
          </div>
          <div class="form-group">
            <label>Chief Complaint</label>
            <input id="cs-cc" value="${item ? item.chief_complaint : ''}" placeholder="What is the patient's main concern?">
          </div>
          <div class="form-group">
            <label>Diagnosis</label>
            <input id="cs-dx" value="${item ? item.diagnosis : ''}">
          </div>
          <div class="form-group">
            <label>Clinical Findings</label>
            <textarea id="cs-findings">${item ? item.findings : ''}</textarea>
          </div>
          <div class="form-group">
            <label>Recommendations / Plan</label>
            <textarea id="cs-recs">${item ? item.recommendations : ''}</textarea>
          </div>
        </div>
        <div class="modal-footer">
          <button class="btn" onclick="closeModal()">Cancel</button>
          <button class="btn btn-primary" onclick="saveConsult(${item ? item.id : 'null'}, ${pid})">Save</button>
        </div>
      </div>
    </div>`;
}

function saveConsult(id, pid) {
  const entry = {
    patient_id:      parseInt(pid),
    doctor_id:       currentUser.id,
    date:            v('cs-date'),
    follow_up:       v('cs-fu'),
    chief_complaint: v('cs-cc'),
    diagnosis:       v('cs-dx'),
    findings:        v('cs-findings'),
    recommendations: v('cs-recs'),
  };
  if (id !== 'null' && id) {
    const i = DB.consultations.findIndex(x => x.id === parseInt(id));
    DB.consultations[i] = { ...DB.consultations[i], ...entry };
  } else {
    DB.consultations.push({ ...entry, id: getNextId() });
  }
  closeModal();
}

// ============================================================
// HEALTH METRICS MODAL
// ============================================================
function metricModal() {
  return `
    <div class="modal-overlay" onclick="if(event.target===this)closeModal()">
      <div class="modal">
        <div class="modal-header">
          <h3>Add Health Reading</h3>
          <button class="close-btn" onclick="closeModal()">✕</button>
        </div>
        <div class="modal-body">
          <div class="form-group">
            <label>Metric Type</label>
            <select id="metric-type" onchange="updateMetricInput()">
              <option value="weight">Weight (kg)</option>
              <option value="blood_pressure">Blood Pressure (mmHg)</option>
              <option value="heart_rate">Heart Rate (bpm)</option>
              <option value="temperature">Temperature (°C)</option>
              <option value="blood_sugar">Blood Sugar (mg/dL)</option>
              <option value="oxygen_saturation">Oxygen Saturation (%)</option>
            </select>
          </div>
          <div id="metric-input-container">
            <div class="form-group">
              <label>Value</label>
              <input id="metric-value" type="number" step="0.1" placeholder="Enter reading value">
            </div>
          </div>
          <div class="form-group">
            <label>Date</label>
            <input id="metric-date" type="date" value="${new Date().toISOString().split('T')[0]}">
          </div>
          <div class="form-group">
            <label>Notes (optional)</label>
            <textarea id="metric-notes" placeholder="Any additional notes..."></textarea>
          </div>
        </div>
        <div class="modal-footer">
          <button class="btn" onclick="closeModal()">Cancel</button>
          <button class="btn btn-primary" onclick="saveMetric()">Save Reading</button>
        </div>
      </div>
    </div>`;
}

function updateMetricInput() {
  const type = document.getElementById('metric-type').value;
  const container = document.getElementById('metric-input-container');
  
  if (type === 'blood_pressure') {
    container.innerHTML = `
      <div class="form-row">
        <div class="form-group">
          <label>Systolic (mmHg)</label>
          <input id="metric-value-systolic" type="number" placeholder="e.g., 140">
        </div>
        <div class="form-group">
          <label>Diastolic (mmHg)</label>
          <input id="metric-value-diastolic" type="number" placeholder="e.g., 90">
        </div>
      </div>`;
  } else {
    container.innerHTML = `
      <div class="form-group">
        <label>Value</label>
        <input id="metric-value" type="number" step="0.1" placeholder="Enter reading value">
      </div>`;
  }
}

function saveMetric() {
  const type = document.getElementById('metric-type').value;
  const date = v('metric-date');
  const notes = v('metric-notes');
  let value;

  if (type === 'blood_pressure') {
    const systolic = document.getElementById('metric-value-systolic');
    const diastolic = document.getElementById('metric-value-diastolic');
    
    if (!systolic || !systolic.value || !diastolic || !diastolic.value) {
      alert('Please enter both systolic and diastolic values');
      return;
    }
    
    value = `${systolic.value}/${diastolic.value}`;
  } else {
    value = parseFloat(v('metric-value'));
    if (!value || isNaN(value)) {
      alert('Please enter a valid numeric value');
      return;
    }
  }

  DB.health_metrics.push({
    id: DB.nextId++,
    patient_id: currentUser.id,
    type: type,
    value: value,
    date: date,
    notes: notes
  });
  
  modal = null;
  render();
  setTimeout(() => {
    if (currentPage === 'health') {
      initHealthCharts();
    }
  }, 100);
}

// ============================================================
// APPOINTMENT MODAL
// ============================================================
function appointmentModal(item) {
  return `
    <div class="modal-overlay" onclick="if(event.target===this)closeModal()">
      <div class="modal">
        <div class="modal-header">
          <h3>${item ? 'Edit' : 'Schedule'} Appointment</h3>
          <button class="close-btn" onclick="closeModal()">✕</button>
        </div>
        <div class="modal-body">
          <div class="form-group">
            <label>Doctor Name</label>
            <input id="apt-doctor" value="${item ? item.doctor : ''}" placeholder="Dr. Juan Dela Cruz">
          </div>
          <div class="form-group">
            <label>Specialty</label>
            <select id="apt-specialty">
              <option ${item && item.specialty === 'General Medicine' ? 'selected' : ''}>General Medicine</option>
              <option ${item && item.specialty === 'Cardiology' ? 'selected' : ''}>Cardiology</option>
              <option ${item && item.specialty === 'Dermatology' ? 'selected' : ''}>Dermatology</option>
              <option ${item && item.specialty === 'Orthopedics' ? 'selected' : ''}>Orthopedics</option>
              <option ${item && item.specialty === 'Pediatrics' ? 'selected' : ''}>Pediatrics</option>
              <option ${item && item.specialty === 'Gynecology' ? 'selected' : ''}>Gynecology</option>
              <option ${item && item.specialty === 'Dentistry' ? 'selected' : ''}>Dentistry</option>
              <option ${item && item.specialty === 'Ophthalmology' ? 'selected' : ''}>Ophthalmology</option>
              <option ${item && item.specialty === 'Other' ? 'selected' : ''}>Other</option>
            </select>
          </div>
          <div class="form-group">
            <label>Hospital/Clinic</label>
            <select id="apt-hospital">
              ${PHILIPPINE_HOSPITALS.map(h => `<option ${item && item.hospital === h ? 'selected' : ''}>${h}</option>`).join('')}
            </select>
          </div>
          <div class="form-row">
            <div class="form-group">
              <label>Date</label>
              <input id="apt-date" type="date" value="${item ? item.date : ''}">
            </div>
            <div class="form-group">
              <label>Time</label>
              <input id="apt-time" type="time" value="${item ? item.time : ''}">
            </div>
          </div>
          <div class="form-group">
            <label>Purpose</label>
            <textarea id="apt-purpose" placeholder="Reason for appointment">${item ? item.purpose : ''}</textarea>
          </div>
          <div class="form-group">
            <label>Notes (optional)</label>
            <textarea id="apt-notes" placeholder="Additional notes">${item ? item.notes : ''}</textarea>
          </div>
        </div>
        <div class="modal-footer">
          <button class="btn" onclick="closeModal()">Cancel</button>
          <button class="btn btn-primary" onclick="saveAppointment(${item ? item.id : 'null'})">Save Appointment</button>
        </div>
      </div>
    </div>`;
}

function saveAppointment(id) {
  const entry = {
    patient_id: currentUser.id,
    doctor:     v('apt-doctor'),
    specialty:  document.getElementById('apt-specialty').value,
    hospital:   document.getElementById('apt-hospital').value,
    date:       v('apt-date'),
    time:       v('apt-time'),
    purpose:    v('apt-purpose'),
    notes:      v('apt-notes'),
  };

  if (id !== 'null' && id) {
    const i = DB.appointments.findIndex(x => x.id === parseInt(id));
    DB.appointments[i] = { ...DB.appointments[i], ...entry };
  } else {
    DB.appointments.push({ ...entry, id: getNextId() });
  }
  closeModal();
}

// ============================================================
// SYMPTOM MODAL
// ============================================================
function symptomModal(item) {
  return `
    <div class="modal-overlay" onclick="if(event.target===this)closeModal()">
      <div class="modal">
        <div class="modal-header">
          <h3>${item ? 'Edit' : 'Log'} Symptom</h3>
          <button class="close-btn" onclick="closeModal()">✕</button>
        </div>
        <div class="modal-body">
          <div class="form-group">
            <label>Symptom</label>
            <input id="sym-symptom" value="${item ? item.symptom : ''}" placeholder="e.g., Headache, Fever, Cough">
          </div>
          <div class="form-row">
            <div class="form-group">
              <label>Severity (1-10)</label>
              <input id="sym-severity" type="number" min="1" max="10" value="${item ? item.severity : ''}" placeholder="1-10">
            </div>
            <div class="form-group">
              <label>Duration</label>
              <input id="sym-duration" value="${item ? item.duration : ''}" placeholder="e.g., 2 hours, 3 days">
            </div>
          </div>
          <div class="form-group">
            <label>Date</label>
            <input id="sym-date" type="date" value="${item ? item.date : new Date().toISOString().split('T')[0]}">
          </div>
          <div class="form-group">
            <label>Notes</label>
            <textarea id="sym-notes" placeholder="Describe the symptom in detail">${item ? item.notes : ''}</textarea>
          </div>
        </div>
        <div class="modal-footer">
          <button class="btn" onclick="closeModal()">Cancel</button>
          <button class="btn btn-primary" onclick="saveSymptom(${item ? item.id : 'null'})">Save Symptom</button>
        </div>
      </div>
    </div>`;
}

function saveSymptom(id) {
  const entry = {
    patient_id: currentUser.id,
    symptom:    v('sym-symptom'),
    severity:   parseInt(v('sym-severity')),
    duration:   v('sym-duration'),
    date:       v('sym-date'),
    notes:      v('sym-notes'),
  };

  if (id !== 'null' && id) {
    const i = DB.symptoms.findIndex(x => x.id === parseInt(id));
    DB.symptoms[i] = { ...DB.symptoms[i], ...entry };
  } else {
    DB.symptoms.push({ ...entry, id: getNextId() });
  }
  closeModal();
}

// ============================================================
// HEALTH GOAL MODAL
// ============================================================
function goalModal(item) {
  return `
    <div class="modal-overlay" onclick="if(event.target===this)closeModal()">
      <div class="modal">
        <div class="modal-header">
          <h3>${item ? 'Edit' : 'Set'} Health Goal</h3>
          <button class="close-btn" onclick="closeModal()">✕</button>
        </div>
        <div class="modal-body">
          <div class="form-group">
            <label>Goal Title</label>
            <input id="goal-title" value="${item ? item.title : ''}" placeholder="e.g., Lose 5kg, Exercise 3x/week">
          </div>
          <div class="form-group">
            <label>Category</label>
            <select id="goal-category">
              <option ${item && item.category === 'Weight Management' ? 'selected' : ''}>Weight Management</option>
              <option ${item && item.category === 'Exercise' ? 'selected' : ''}>Exercise</option>
              <option ${item && item.category === 'Nutrition' ? 'selected' : ''}>Nutrition</option>
              <option ${item && item.category === 'Medication' ? 'selected' : ''}>Medication</option>
              <option ${item && item.category === 'Lifestyle' ? 'selected' : ''}>Lifestyle</option>
              <option ${item && item.category === 'Other' ? 'selected' : ''}>Other</option>
            </select>
          </div>
          <div class="form-group">
            <label>Description</label>
            <textarea id="goal-description" placeholder="Describe your goal in detail">${item ? item.description : ''}</textarea>
          </div>
          <div class="form-group">
            <label>Target Date</label>
            <input id="goal-target-date" type="date" value="${item ? item.target_date : ''}">
          </div>
          <div class="form-group">
            <label>Current Progress (%)</label>
            <input id="goal-progress" type="number" min="0" max="100" value="${item ? item.progress : '0'}" placeholder="0-100">
          </div>
        </div>
        <div class="modal-footer">
          <button class="btn" onclick="closeModal()">Cancel</button>
          <button class="btn btn-primary" onclick="saveGoal(${item ? item.id : 'null'})">Save Goal</button>
        </div>
      </div>
    </div>`;
}

function saveGoal(id) {
  const entry = {
    patient_id:   currentUser.id,
    title:        v('goal-title'),
    category:     document.getElementById('goal-category').value,
    description:  v('goal-description'),
    target_date:  v('goal-target-date'),
    progress:     parseInt(v('goal-progress')) || 0,
    status:       'active',
  };

  if (id !== 'null' && id) {
    const i = DB.healthGoals.findIndex(x => x.id === parseInt(id));
    DB.healthGoals[i] = { ...DB.healthGoals[i], ...entry };
  } else {
    DB.healthGoals.push({ ...entry, id: getNextId() });
  }
  closeModal();
}

// ============================================================
// FAMILY MEMBER MODAL
// ============================================================
function familyModal(item) {
  return `
    <div class="modal-overlay" onclick="if(event.target===this)closeModal()">
      <div class="modal">
        <div class="modal-header">
          <h3>${item ? 'Edit' : 'Add'} Family Member</h3>
          <button class="close-btn" onclick="closeModal()">✕</button>
        </div>
        <div class="modal-body">
          <div class="form-row">
            <div class="form-group">
              <label>Full Name</label>
              <input id="fam-name" value="${item ? item.name : ''}" placeholder="Full name">
            </div>
            <div class="form-group">
              <label>Relationship</label>
              <select id="fam-relationship">
                <option ${item && item.relationship === 'Father' ? 'selected' : ''}>Father</option>
                <option ${item && item.relationship === 'Mother' ? 'selected' : ''}>Mother</option>
                <option ${item && item.relationship === 'Brother' ? 'selected' : ''}>Brother</option>
                <option ${item && item.relationship === 'Sister' ? 'selected' : ''}>Sister</option>
                <option ${item && item.relationship === 'Son' ? 'selected' : ''}>Son</option>
                <option ${item && item.relationship === 'Daughter' ? 'selected' : ''}>Daughter</option>
                <option ${item && item.relationship === 'Spouse' ? 'selected' : ''}>Spouse</option>
                <option ${item && item.relationship === 'Grandparent' ? 'selected' : ''}>Grandparent</option>
                <option ${item && item.relationship === 'Other' ? 'selected' : ''}>Other</option>
              </select>
            </div>
          </div>
          <div class="form-row">
            <div class="form-group">
              <label>Age</label>
              <input id="fam-age" type="number" value="${item ? item.age : ''}" placeholder="Age in years">
            </div>
            <div class="form-group">
              <label>Blood Type</label>
              <select id="fam-blood-type">
                <option ${item && item.blood_type === 'A+' ? 'selected' : ''}>A+</option>
                <option ${item && item.blood_type === 'A-' ? 'selected' : ''}>A-</option>
                <option ${item && item.blood_type === 'B+' ? 'selected' : ''}>B+</option>
                <option ${item && item.blood_type === 'B-' ? 'selected' : ''}>B-</option>
                <option ${item && item.blood_type === 'AB+' ? 'selected' : ''}>AB+</option>
                <option ${item && item.blood_type === 'AB-' ? 'selected' : ''}>AB-</option>
                <option ${item && item.blood_type === 'O+' ? 'selected' : ''}>O+</option>
                <option ${item && item.blood_type === 'O-' ? 'selected' : ''}>O-</option>
              </select>
            </div>
          </div>
          <div class="form-group">
            <label>Medical Conditions</label>
            <textarea id="fam-conditions" placeholder="List any known medical conditions">${item ? item.conditions : ''}</textarea>
          </div>
          <div class="form-group">
            <label>Allergies</label>
            <textarea id="fam-allergies" placeholder="List any known allergies">${item ? item.allergies : ''}</textarea>
          </div>
          <div class="form-group">
            <label>Current Medications</label>
            <textarea id="fam-medications" placeholder="List current medications">${item ? item.medications : ''}</textarea>
          </div>
          <div class="form-group">
            <label>Additional Notes</label>
            <textarea id="fam-notes" placeholder="Any other relevant health information">${item ? item.notes : ''}</textarea>
          </div>
        </div>
        <div class="modal-footer">
          <button class="btn" onclick="closeModal()">Cancel</button>
          <button class="btn btn-primary" onclick="saveFamilyMember(${item ? item.id : 'null'})">Save Member</button>
        </div>
      </div>
    </div>`;
}

function saveFamilyMember(id) {
  const entry = {
    patient_id:   currentUser.id,
    name:         v('fam-name'),
    relationship: document.getElementById('fam-relationship').value,
    age:          v('fam-age') ? parseInt(v('fam-age')) : null,
    blood_type:   document.getElementById('fam-blood-type').value,
    conditions:   v('fam-conditions'),
    allergies:    v('fam-allergies'),
    medications:  v('fam-medications'),
    notes:        v('fam-notes'),
  };

  if (id !== 'null' && id) {
    const i = DB.familyMembers.findIndex(x => x.id === parseInt(id));
    DB.familyMembers[i] = { ...DB.familyMembers[i], ...entry };
  } else {
    DB.familyMembers.push({ ...entry, id: getNextId() });
  }
  closeModal();
}

// ============================================================
// ARTICLE MODAL
// ============================================================
function articleModal(article) {
  return `
    <div class="modal-overlay" onclick="if(event.target===this)closeModal()">
      <div class="modal modal-lg">
        <div class="modal-header">
          <h3>${article.title}</h3>
          <button class="close-btn" onclick="closeModal()">✕</button>
        </div>
        <div class="modal-body">
          <div style="margin-bottom:16px">
            <span class="badge badge-blue">${article.category}</span>
            <span style="margin-left:12px;font-size:12px;color:var(--text3)">${article.read_time || '5 min read'}</span>
          </div>
          <div style="line-height:1.6;font-size:14px">
            ${article.content || article.excerpt}
          </div>
        </div>
        <div class="modal-footer">
          <button class="btn" onclick="closeModal()">Close</button>
        </div>
      </div>
    </div>`;
}

// ============================================================
// GENERIC DELETE
// ============================================================
function delItem(table, id) {
  if (!confirm('Delete this record permanently?')) return;
  DB[table] = DB[table].filter(x => x.id !== id);
  render();
}
