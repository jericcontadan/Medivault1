/**
 * MediVault — db.js
 * In-memory data store (simulates a MySQL database).
 * In a real app, replace this with actual API / backend calls.
 */

// Load persisted data from localStorage
function loadPersistedData() {
  const savedUsers = localStorage.getItem('medivault-users');
  const savedProfiles = localStorage.getItem('medivault-profiles');
  const savedEmergency = localStorage.getItem('medivault-emergency');
  const savedNextId = localStorage.getItem('medivault-nextId');

  if (savedUsers) DB.users = JSON.parse(savedUsers);
  if (savedProfiles) DB.profiles = JSON.parse(savedProfiles);
  if (savedEmergency) DB.emergency = JSON.parse(savedEmergency);
  if (savedNextId) DB.nextId = parseInt(savedNextId);
}

// Save data to localStorage
function savePersistedData() {
  localStorage.setItem('medivault-users', JSON.stringify(DB.users));
  localStorage.setItem('medivault-profiles', JSON.stringify(DB.profiles));
  localStorage.setItem('medivault-emergency', JSON.stringify(DB.emergency));
  localStorage.setItem('medivault-nextId', DB.nextId.toString());
}

const DB = {
  users: [
    { id: 1, name: 'Maria Santos',  email: 'maria@demo.com',  password: 'demo123', role: 'patient', avatar: 'MS', profilePicture: null },
    { id: 2, name: 'Dr. Juan Reyes', email: 'doctor@demo.com', password: 'demo123', role: 'doctor',  avatar: 'JR', specialty: 'General Medicine', profilePicture: null },
  ],

  profiles: {
    1: {
      name: 'Maria Santos',
      age: 29,
      birthdate: '1995-06-14',
      blood_type: 'O+',
      sex: 'Female',
      address: 'Quezon City, Metro Manila',
      phone: '09171234567',
      philhealth: 'PH-12345678',
      hmo: 'Maxicare',
      height_cm: 165,
      weight_kg: 69.8,
    },
  },

  emergency: {
    1: { name: 'Pedro Santos', relation: 'Spouse', phone: '09187654321' },
  },

  medical_history: [
    { id: 1, patient_id: 1, type: 'illness', title: 'Dengue Fever',      date: '2021-08-12', notes: "Hospitalized for 5 days at St. Luke's Medical Center" },
    { id: 2, patient_id: 1, type: 'allergy', title: 'Penicillin',        category: 'Medicine',     severity: 'Severe',   notes: 'Anaphylactic reaction, requires EpiPen' },
    { id: 3, patient_id: 1, type: 'allergy', title: 'Shellfish',         category: 'Food',          severity: 'Moderate', notes: 'Skin rash and hives' },
    { id: 4, patient_id: 1, type: 'family',  title: 'Hypertension',      relation: 'Father',        notes: 'Managed with antihypertensives since age 50' },
    { id: 5, patient_id: 1, type: 'family',  title: 'Type 2 Diabetes',   relation: 'Maternal Grandmother', notes: 'Diet-controlled' },
  ],

  vaccinations: [
    { id: 1, patient_id: 1, name: 'COVID-19 (Pfizer)',          date: '2021-04-15', dose: 'Dose 1/2', facility: 'UP Health Service' },
    { id: 2, patient_id: 1, name: 'COVID-19 (Pfizer)',          date: '2021-05-06', dose: 'Dose 2/2', facility: 'UP Health Service' },
    { id: 3, patient_id: 1, name: 'COVID-19 Booster (Moderna)', date: '2022-01-18', dose: 'Booster',  facility: 'Quezon City vaccination site' },
    { id: 4, patient_id: 1, name: 'Flu Vaccine',                date: '2023-10-20', dose: 'Annual',   facility: 'Healthway Clinic' },
    { id: 5, patient_id: 1, name: 'Flu Vaccine',                date: '2024-10-15', dose: 'Annual',   facility: 'Healthway Clinic' },
  ],

  visits: [
    { id: 1, patient_id: 1, date: '2023-09-05', doctor: 'Dr. Ana Flores', hospital: "St. Luke's Medical Center", reason: 'Annual physical exam',        notes: 'All results normal. BMI slightly elevated.' },
    { id: 2, patient_id: 1, date: '2024-02-14', doctor: 'Dr. Santos',     hospital: 'Healthway Clinic',          reason: 'Flu-like symptoms',            notes: 'Prescribed Paracetamol and rest. No complications.' },
    { id: 3, patient_id: 1, date: '2024-06-20', doctor: 'Dr. Reyes',      hospital: 'Healthway Clinic',          reason: 'Persistent headaches',         notes: 'Likely tension headaches. Advised hydration and stress management.' },
    { id: 4, patient_id: 1, date: '2025-01-10', doctor: 'Dr. Juan Reyes', hospital: 'Philippine Heart Center',   reason: 'Routine BP monitoring',        notes: 'BP 140/90 mmHg. Stage 1 hypertension. Started on Losartan.' },
  ],

  medications: [
    { id: 1, patient_id: 1, name: 'Losartan 50mg',      dosage: '50mg',     frequency: 'Once daily (morning)',    start: '2025-01-10', end: '',           current: true,  expiry: '2026-07-10', notes: 'For blood pressure management' },
    { id: 2, patient_id: 1, name: 'Vitamin D3',          dosage: '1000 IU',  frequency: 'Once daily',              start: '2024-12-01', end: '',           current: true,  expiry: '2026-09-01', notes: 'Deficiency noted in last bloodwork' },
    { id: 3, patient_id: 1, name: 'Omega-3 Fish Oil',    dosage: '1000mg',   frequency: 'Once daily with meal',    start: '2024-12-01', end: '',           current: true,  expiry: '2025-10-31', notes: 'Cardiovascular support' },
    { id: 4, patient_id: 1, name: 'Amoxicillin',         dosage: '500mg',    frequency: 'Three times daily',       start: '2024-09-05', end: '2024-09-12', current: false, expiry: '2025-03-05', notes: 'Completed antibiotic course for UTI' },
    { id: 5, patient_id: 1, name: 'Paracetamol 500mg',   dosage: '500mg',    frequency: 'Every 6 hours as needed', start: '2024-02-14', end: '2024-02-18', current: false, expiry: '2025-05-14', notes: 'For flu symptoms' },
  ],

  consultations: [
    {
      id: 1,
      patient_id: 1,
      doctor_id: 2,
      date: '2025-01-10',
      chief_complaint: 'Elevated blood pressure readings at home',
      diagnosis: 'Stage 1 Hypertension',
      findings: 'BP: 140/90 mmHg on three separate readings. No signs of end-organ damage. ECG normal.',
      recommendations: 'Low sodium diet (<2g/day), regular aerobic exercise 30min/day, Losartan 50mg OD, follow-up in 3 months.',
      follow_up: '2025-04-10',
    },
  ],

  health_metrics: [
    { id: 1, patient_id: 1, type: 'weight',        value: 68.5, date: '2024-12-01', notes: '' },
    { id: 2, patient_id: 1, type: 'weight',        value: 70.2, date: '2024-12-08', notes: '' },
    { id: 3, patient_id: 1, type: 'weight',        value: 69.8, date: '2024-12-15', notes: '' },
    { id: 4, patient_id: 1, type: 'blood_pressure', value: '138/88', date: '2024-12-01', notes: '' },
    { id: 5, patient_id: 1, type: 'blood_pressure', value: '140/90', date: '2024-12-08', notes: '' },
    { id: 6, patient_id: 1, type: 'blood_pressure', value: '135/85', date: '2024-12-15', notes: '' },
    { id: 7, patient_id: 1, type: 'heart_rate',    value: 72, date: '2024-12-01', notes: '' },
    { id: 8, patient_id: 1, type: 'heart_rate',    value: 68, date: '2024-12-08', notes: '' },
    { id: 9, patient_id: 1, type: 'heart_rate',    value: 75, date: '2024-12-15', notes: '' },
  ],

  lab_results: [
    { id: 1, patient_id: 1, test_name: 'Complete Blood Count (CBC)', date: '2024-12-15', facility: 'Philippine Heart Center', results: 'Normal range', notes: 'All values within normal limits' },
    { id: 2, patient_id: 1, test_name: 'Blood Glucose (Fasting)', date: '2024-12-15', facility: 'Philippine Heart Center', results: '102 mg/dL', notes: 'Slightly elevated, monitor diet' },
    { id: 3, patient_id: 1, test_name: 'Lipid Panel', date: '2024-11-20', facility: 'Healthway Clinic', results: 'Total cholesterol: 195 mg/dL', notes: 'Borderline high, recommend exercise' },
  ],

  appointments: [
    { id: 1, patient_id: 1, doctor: 'Dr. Ana Flores', specialty: 'General Medicine', hospital: "St. Luke's Medical Center", date: '2025-02-15', time: '10:00', purpose: 'Annual physical exam', notes: 'Bring previous lab results' },
    { id: 2, patient_id: 1, doctor: 'Dr. Santos', specialty: 'Cardiology', hospital: 'Philippine Heart Center', date: '2025-03-20', time: '14:30', purpose: 'Follow-up for hypertension', notes: 'Bring BP log' },
  ],

  symptoms: [
    { id: 1, patient_id: 1, symptom: 'Headache', severity: 6, duration: '2 hours', date: '2024-12-20', notes: 'Tension headache, relieved with rest' },
    { id: 2, patient_id: 1, symptom: 'Fatigue', severity: 4, duration: '3 days', date: '2024-12-18', notes: 'Feeling tired, possibly due to stress' },
  ],

  healthGoals: [
    { id: 1, patient_id: 1, title: 'Lower blood pressure to 120/80', category: 'Lifestyle', description: 'Reduce sodium intake and increase exercise to manage hypertension', target_date: '2025-06-01', progress: 25, status: 'active' },
    { id: 2, patient_id: 1, title: 'Lose 5kg', category: 'Weight Management', description: 'Healthy weight loss through diet and exercise', target_date: '2025-08-01', progress: 40, status: 'active' },
    { id: 3, patient_id: 1, title: 'Exercise 3x per week', category: 'Exercise', description: 'Regular cardio exercise for cardiovascular health', target_date: '2025-12-31', progress: 100, status: 'completed', completed_date: '2025-01-15' },
  ],

  familyMembers: [
    { id: 1, patient_id: 1, name: 'Pedro Santos', relationship: 'Spouse', age: 32, blood_type: 'O+', conditions: 'None known', allergies: 'None', medications: 'None', notes: 'Generally healthy' },
    { id: 2, patient_id: 1, name: 'Rosa Santos', relationship: 'Mother', age: 55, blood_type: 'A-', conditions: 'Hypertension', allergies: 'Penicillin', medications: 'Losartan 25mg daily', notes: 'Family history of heart disease' },
  ],

  healthArticles: [
    { id: 1, title: 'Understanding Hypertension', category: 'Cardiovascular Health', read_time: '5 min read', excerpt: 'Learn about high blood pressure, its causes, symptoms, and management strategies...', content: 'Hypertension, or high blood pressure, is a common condition that affects millions worldwide. It occurs when the force of blood against your artery walls is consistently too high...' },
    { id: 2, title: 'Healthy Eating for Heart Health', category: 'Nutrition', read_time: '7 min read', excerpt: 'Discover heart-healthy foods and dietary patterns that can reduce your risk of cardiovascular disease...', content: 'A heart-healthy diet focuses on whole foods, lean proteins, and healthy fats while limiting processed foods and sodium...' },
    { id: 3, title: 'Stress Management Techniques', category: 'Mental Health', read_time: '6 min read', excerpt: 'Effective strategies for managing stress and improving your overall well-being...', content: 'Chronic stress can have significant impacts on both physical and mental health. Learning to manage stress effectively is crucial for maintaining wellness...' },
  ],

  documents: [],
  wearableData: [],
  insuranceInfo: [],
  allergies: [],

  nextId: 200,
};

// Load persisted data on startup
loadPersistedData();
