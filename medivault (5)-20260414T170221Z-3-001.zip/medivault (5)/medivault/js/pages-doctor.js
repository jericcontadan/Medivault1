/**
 * MediVault — pages-doctor.js
 * Renderers for all doctor-facing pages.
 */

// ============================================================
// DOCTOR DASHBOARD
// ============================================================
function renderDoctorDashboard() {
  const patients = DB.users.filter(u => u.role === 'patient');
  const upcoming = DB.consultations.filter(c => c.follow_up && new Date(c.follow_up) > new Date());

  return `
  <div class="page-header">
    <div class="page-header-left"><h2>Doctor Dashboard</h2><p>Welcome back, ${currentUser.name}</p></div>
  </div>
  <div class="page-body">
    <div class="grid-4" style="margin-bottom:1.25rem">
      <div class="stat-card stat-blue"><div class="stat-label">Total Patients</div><div class="stat-value">${patients.length}</div><div class="stat-sub">registered</div></div>
      <div class="stat-card stat-green"><div class="stat-label">Consultations</div><div class="stat-value">${DB.consultations.length}</div><div class="stat-sub">all time</div></div>
      <div class="stat-card stat-amber"><div class="stat-label">Follow-ups Due</div><div class="stat-value">${upcoming.length}</div><div class="stat-sub">upcoming</div></div>
      <div class="stat-card stat-purple">
        <div class="stat-label">Today</div>
        <div class="stat-value" style="font-size:18px">${new Date().toLocaleDateString('en-PH', { month: 'short', day: 'numeric' })}</div>
        <div class="stat-sub">${new Date().toLocaleDateString('en-PH', { weekday: 'long' })}</div>
      </div>
    </div>

    <div class="grid-2">
      <!-- Patient List -->
      <div class="card">
        <div class="card-header"><h3>Patient List</h3><button class="btn btn-sm" onclick="navigate('patients')">View all</button></div>
        <div class="card-body" style="padding:0">
          <div class="table-wrap">
            <table>
              <thead><tr><th>Patient</th><th>Last Visit</th><th></th></tr></thead>
              <tbody>
                ${patients.map(pt => {
                  const lv = DB.visits.filter(vv => vv.patient_id === pt.id).sort((a, b) => b.date.localeCompare(a.date))[0];
                  return `<tr>
                    <td>
                      <div style="display:flex;align-items:center;gap:8px">
                        <div class="user-avatar" style="width:28px;height:28px;font-size:11px">
                          ${pt.profilePicture ? `<img src="${pt.profilePicture}" alt="Profile" style="width:100%;height:100%;border-radius:50%;object-fit:cover;">` : pt.avatar}
                        </div>
                        <span style="font-size:13px">${pt.name}</span>
                      </div>
                    </td>
                    <td style="font-size:12px;color:var(--text2)">${lv ? lv.date : 'No visits'}</td>
                    <td><button class="btn btn-sm btn-blue" onclick="viewPatient(${pt.id})">View</button></td>
                  </tr>`;
                }).join('')}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      <!-- Upcoming Follow-ups -->
      <div class="card">
        <div class="card-header"><h3>Upcoming Follow-ups</h3></div>
        <div class="card-body">
          ${upcoming.length === 0 ? '<div class="empty-state"><p>No upcoming follow-ups</p></div>' : ''}
          ${upcoming.map(c => {
            const pt = DB.users.find(u => u.id === c.patient_id);
            return `
              <div style="display:flex;justify-content:space-between;align-items:center;padding:8px 0;border-bottom:1px solid var(--border)">
                <div>
                  <div style="font-size:13px;font-weight:500">${pt ? pt.name : 'Unknown'}</div>
                  <div style="font-size:11px;color:var(--text2)">${c.diagnosis}</div>
                </div>
                <span class="badge badge-amber">${c.follow_up}</span>
              </div>`;
          }).join('')}
        </div>
      </div>
    </div>
  </div>`;
}

// ============================================================
// DOCTOR PATIENTS (list + patient detail view)
// ============================================================
function renderDoctorPatients() {
  if (selectedPatient) return renderPatientView();

  const patients = DB.users
    .filter(u => u.role === 'patient')
    .filter(p => !searchQuery
      || p.name.toLowerCase().includes(searchQuery.toLowerCase())
      || String(p.id).includes(searchQuery));

  return `
  <div class="page-header">
    <div class="page-header-left"><h2>Patients</h2><p>Search and view patient records</p></div>
  </div>
  <div class="page-body">
    <div class="search-bar">
      <input class="search-input" placeholder="Search by name or ID..." value="${searchQuery}" oninput="searchQuery=this.value;render()">
    </div>
    <div class="card">
      <div class="card-body" style="padding:0">
        <div class="table-wrap">
          <table>
            <thead><tr><th>Patient</th><th>ID</th><th>Blood Type</th><th>Last Visit</th><th>Allergies</th><th>Active Meds</th><th></th></tr></thead>
            <tbody>
              ${patients.map(pt => {
                const lv = DB.visits.filter(vv => vv.patient_id === pt.id).sort((a, b) => b.date.localeCompare(a.date))[0];
                const al = DB.medical_history.filter(m => m.patient_id === pt.id && m.type === 'allergy').length;
                const md = DB.medications.filter(m => m.patient_id === pt.id && m.current).length;
                const pr = DB.profiles[pt.id] || {};
                return `<tr>
                  <td>
                    <div style="display:flex;align-items:center;gap:8px">
                      <div class="user-avatar" style="width:32px;height:32px">${pt.avatar}</div>
                      <span style="font-size:13px;font-weight:500">${pt.name}</span>
                    </div>
                  </td>
                  <td style="color:var(--text3);font-size:12px">PT-${String(pt.id).padStart(4, '0')}</td>
                  <td>${pr.blood_type ? `<span class="badge badge-red">${pr.blood_type}</span>` : '<span style="color:var(--text3)">—</span>'}</td>
                  <td style="font-size:12px;color:var(--text2)">${lv ? lv.date : 'No visits'}</td>
                  <td>${al > 0 ? `<span class="badge badge-red">${al}</span>` : '<span style="color:var(--text3)">None</span>'}</td>
                  <td>${md > 0 ? `<span class="badge badge-green">${md}</span>` : '<span style="color:var(--text3)">None</span>'}</td>
                  <td><button class="btn btn-sm btn-blue" onclick="viewPatient(${pt.id})">View Records</button></td>
                </tr>`;
              }).join('')}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>`;
}

function viewPatient(pid) { selectedPatient = pid; currentPage = 'patients'; render(); }

function renderPatientView() {
  const pt       = DB.users.find(u => u.id === selectedPatient);
  if (!pt) { selectedPatient = null; return renderDoctorPatients(); }

  const pr       = DB.profiles[selectedPatient] || {};
  const visits   = DB.visits.filter(v => v.patient_id === selectedPatient).sort((a, b) => b.date.localeCompare(a.date));
  const meds     = DB.medications.filter(m => m.patient_id === selectedPatient);
  const allergies= DB.medical_history.filter(m => m.patient_id === selectedPatient && m.type === 'allergy');
  const illnesses= DB.medical_history.filter(m => m.patient_id === selectedPatient && m.type === 'illness');
  const consults = DB.consultations.filter(c => c.patient_id === selectedPatient).sort((a, b) => b.date.localeCompare(a.date));
  const vacc     = DB.vaccinations.filter(v => v.patient_id === selectedPatient);

  return `
  <div class="page-header">
    <div class="page-header-left">
      <div style="display:flex;align-items:center;gap:10px;margin-bottom:4px">
        <button class="btn btn-sm" onclick="selectedPatient=null;render()">← Back</button>
        <h2 style="font-family:'Fraunces',serif;font-size:20px">${pt.name}</h2>
        <span class="badge badge-blue">PT-${String(pt.id).padStart(4, '0')}</span>
      </div>
      <p style="color:var(--text2);font-size:13px">Full patient records</p>
    </div>
    <button class="btn btn-primary" onclick="openModal('add-consult-${selectedPatient}')">+ Add Consultation</button>
  </div>
  <div class="page-body">
    <div class="grid-4" style="margin-bottom:1.25rem">
      <div class="stat-card"><div class="stat-label">Blood Type</div><div class="stat-value" style="font-size:22px;color:var(--red)">${pr.blood_type || '—'}</div></div>
      <div class="stat-card"><div class="stat-label">Age</div><div class="stat-value" style="font-size:22px">${pr.age || '—'}</div></div>
      <div class="stat-card stat-red"><div class="stat-label">Allergies</div><div class="stat-value" style="font-size:22px">${allergies.length}</div></div>
      <div class="stat-card stat-green"><div class="stat-label">Active Meds</div><div class="stat-value" style="font-size:22px">${meds.filter(m => m.current).length}</div></div>
    </div>

    ${allergies.length > 0
      ? `<div style="background:var(--red-bg);border:1px solid var(--red);border-radius:var(--radius);padding:10px 14px;margin-bottom:1rem;font-size:13px;color:var(--red)">
           ⚠️ <strong>Allergy Alert:</strong> ${allergies.map(a => `${a.title} (${a.severity || '?'})`).join(', ')}
         </div>`
      : ''}

    <div class="grid-2" style="margin-bottom:1.25rem">
      <!-- Consultation Notes -->
      <div class="card">
        <div class="card-header"><h3>Consultation Notes</h3></div>
        <div class="card-body">
          ${consults.length === 0 ? '<div class="empty-state"><p>No consultations yet</p></div>' : ''}
          ${consults.map(c => `
            <div style="padding:12px;background:var(--bg3);border-radius:var(--radius);margin-bottom:10px">
              <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px">
                <span style="font-size:13px;font-weight:600">${c.date}</span>
                ${c.follow_up ? `<span class="badge badge-amber">Follow-up: ${c.follow_up}</span>` : ''}
              </div>
              <div style="font-size:12px;margin-bottom:4px;color:var(--text2)"><strong style="color:var(--text)">Chief Complaint:</strong> ${c.chief_complaint}</div>
              <div style="font-size:12px;margin-bottom:4px;color:var(--text2)"><strong style="color:var(--text)">Diagnosis:</strong> ${c.diagnosis}</div>
              <div style="font-size:12px;margin-bottom:4px;color:var(--text2)"><strong style="color:var(--text)">Findings:</strong> ${c.findings}</div>
              <div style="font-size:12px;color:var(--text2)"><strong style="color:var(--text)">Recommendations:</strong> ${c.recommendations}</div>
              <div style="display:flex;gap:4px;margin-top:8px">
                <button class="btn btn-sm" onclick="openModal('edit-consult-${c.id}')">Edit</button>
                <button class="btn btn-sm btn-danger" onclick="delItem('consultations',${c.id})">Del</button>
              </div>
            </div>`).join('')}
        </div>
      </div>

      <!-- Visit History -->
      <div class="card">
        <div class="card-header"><h3>Visit History</h3></div>
        <div class="card-body" style="padding-top:0.75rem">
          ${visits.slice(0, 5).map(vv => `
            <div class="timeline-item">
              <div class="timeline-dot"></div>
              <div class="timeline-content">
                <div class="timeline-date">${vv.date}</div>
                <div class="timeline-title">${vv.reason}</div>
                <div class="timeline-detail">${vv.doctor} &middot; ${vv.hospital}</div>
              </div>
            </div>`).join('')}
          ${visits.length === 0 ? '<div class="empty-state"><p>No visits</p></div>' : ''}
        </div>
      </div>
    </div>

    <div class="grid-2">
      <!-- Active Medications -->
      <div class="card">
        <div class="card-header"><h3>Active Medications</h3></div>
        <div class="card-body" style="padding:0">
          ${meds.filter(m => m.current).length === 0 ? '<div class="empty-state" style="padding:1.5rem"><p>None</p></div>' : ''}
          <div class="table-wrap">
            <table>
              <thead><tr><th>Medication</th><th>Dosage</th><th>Frequency</th></tr></thead>
              <tbody>
                ${meds.filter(m => m.current).map(m => `
                  <tr>
                    <td style="font-weight:500">${m.name}</td>
                    <td>${m.dosage}</td>
                    <td>${m.frequency}</td>
                  </tr>`).join('')}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      <!-- Medical History & Allergies -->
      <div class="card">
        <div class="card-header"><h3>Medical History & Allergies</h3></div>
        <div class="card-body">
          ${[...allergies, ...illnesses].length === 0 ? '<div class="empty-state"><p>No records</p></div>' : ''}
          ${[...allergies, ...illnesses].map(m => `
            <div style="display:flex;justify-content:space-between;align-items:center;padding:7px 0;border-bottom:1px solid var(--border)">
              <span style="font-size:13px">
                ${m.title}
                ${m.notes ? `<span style="font-size:11px;color:var(--text3)"> — ${m.notes.slice(0, 40)}</span>` : ''}
              </span>
              <span class="badge ${m.type === 'allergy' ? 'badge-red' : 'badge-blue'}">${m.type}</span>
            </div>`).join('')}
        </div>
      </div>
    </div>
  </div>`;
}

// ============================================================
// DOCTOR CONSULTATIONS
// ============================================================
function renderDoctorConsultations() {
  const all = DB.consultations.sort((a, b) => b.date.localeCompare(a.date));

  return `
  <div class="page-header">
    <div class="page-header-left"><h2>All Consultations</h2><p>All patient consultation notes</p></div>
  </div>
  <div class="page-body">
    <div class="card">
      <div class="card-body" style="padding:0">
        ${all.length === 0 ? '<div class="empty-state"><p>No consultations yet</p></div>' : ''}
        <div class="table-wrap">
          <table>
            <thead><tr><th>Patient</th><th>Date</th><th>Chief Complaint</th><th>Diagnosis</th><th>Follow-up</th><th></th></tr></thead>
            <tbody>
              ${all.map(c => {
                const pt = DB.users.find(u => u.id === c.patient_id);
                return `<tr>
                  <td style="font-weight:500">${pt ? pt.name : 'Unknown'}</td>
                  <td style="font-size:12px">${c.date}</td>
                  <td style="font-size:12px;color:var(--text2);max-width:150px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${c.chief_complaint}</td>
                  <td style="font-size:13px">${c.diagnosis}</td>
                  <td>${c.follow_up ? `<span class="badge badge-amber">${c.follow_up}</span>` : '<span style="color:var(--text3)">—</span>'}</td>
                  <td style="white-space:nowrap">
                    <button class="btn btn-sm" onclick="openModal('edit-consult-${c.id}')">Edit</button>
                    <button class="btn btn-sm btn-danger" onclick="delItem('consultations',${c.id})">Del</button>
                  </td>
                </tr>`;
              }).join('')}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>`;
}

// ============================================================
// DOCTOR SCHEDULE
// ============================================================
function renderDoctorSchedule() {
  const upcoming = DB.consultations
    .filter(c => c.follow_up && new Date(c.follow_up) > new Date())
    .sort((a, b) => a.follow_up.localeCompare(b.follow_up));
  const past = DB.consultations
    .filter(c => c.follow_up && new Date(c.follow_up) <= new Date())
    .sort((a, b) => b.follow_up.localeCompare(a.follow_up));

  return `
  <div class="page-header">
    <div class="page-header-left"><h2>Schedule</h2><p>Upcoming and past follow-up appointments</p></div>
  </div>
  <div class="page-body">
    <div class="card" style="margin-bottom:1rem">
      <div class="card-header"><h3>Upcoming Follow-ups</h3><span class="badge badge-amber">${upcoming.length}</span></div>
      <div class="card-body">
        ${upcoming.length === 0 ? '<div class="empty-state"><p>No upcoming appointments</p></div>' : ''}
        ${upcoming.map(c => {
          const pt = DB.users.find(u => u.id === c.patient_id);
          const d  = new Date(c.follow_up);
          return `
            <div class="card" style="margin-bottom:10px;background:var(--bg3)">
              <div class="card-body" style="display:flex;align-items:center;gap:16px">
                <div style="background:var(--blue-bg);border:1px solid var(--blue);border-radius:var(--radius);padding:10px 14px;text-align:center;flex-shrink:0">
                  <div style="font-size:11px;color:#58a6ff">${d.toLocaleDateString('en-PH', { month: 'short' })}</div>
                  <div style="font-size:22px;font-weight:700;color:#58a6ff">${d.getDate()}</div>
                </div>
                <div style="flex:1">
                  <div style="font-weight:600">${pt ? pt.name : 'Unknown'}</div>
                  <div style="font-size:12px;color:var(--text2)">Follow-up for: <strong>${c.diagnosis}</strong></div>
                </div>
                <button class="btn btn-sm btn-blue" onclick="viewPatient(${c.patient_id});navigate('patients')">View Patient</button>
              </div>
            </div>`;
        }).join('')}
      </div>
    </div>
  </div>`;
}

// ============================================================
// DOCTOR PROFILE PAGE
// ============================================================
function renderDoctorProfile() {
  return `
  <div class="page-header">
    <div class="page-header-left"><h2>My Profile</h2><p>Personal and professional information</p></div>
  </div>
  <div class="page-body">
    <div class="grid-2" style="margin-bottom:1.25rem">
      <!-- Personal Info -->
      <div class="card">
        <div class="card-header"><h3>Personal Information</h3></div>
        <div class="card-body">
          <div class="profile-upload-wrapper" style="margin-bottom:1.25rem">
            <div class="profile-photo">
              ${currentUser.profilePicture ? `<img src="${currentUser.profilePicture}" alt="Profile Picture">` : currentUser.avatar}
            </div>
            <div class="profile-upload-actions">
              <div class="profile-name">${currentUser.name}</div>
              <div class="profile-email">${currentUser.email}</div>
              <label for="profile-pic" class="upload-btn">
                <span>Change Photo</span>
                <span class="upload-icon">📷</span>
                <input type="file" id="profile-pic" accept="image/*" onchange="uploadProfilePicture()">
              </label>
              <div class="upload-hint">Square image recommended. Saves automatically.</div>
            </div>
          </div>
          <div class="form-group" style="margin-bottom:12px">
            <label>Full Name</label>
            <input id="d-name" value="${currentUser.name}">
          </div>
          <div class="form-group" style="margin-bottom:12px">
            <label>Email</label>
            <input id="d-email" type="email" value="${currentUser.email}">
          </div>
          <div class="form-group" style="margin-bottom:12px">
            <label>Specialty</label>
            <input id="d-specialty" value="${currentUser.specialty || ''}" placeholder="e.g. General Medicine">
          </div>
          <button class="btn btn-primary" onclick="saveDoctorProfile()">Save Profile</button>
          <div id="d-saved" style="margin-top:8px"></div>
        </div>
      </div>

      <!-- Professional Info -->
      <div class="card">
        <div class="card-header"><h3>Professional Information</h3></div>
        <div class="card-body">
          <div style="font-size:14px;color:var(--text2);margin-bottom:16px">
            <div>👨‍⚕️ <strong>Role:</strong> ${currentUser.role.charAt(0).toUpperCase() + currentUser.role.slice(1)}</div>
            <div>🏥 <strong>License:</strong> PRC-${currentUser.id.toString().padStart(6, '0')}</div>
            <div>📅 <strong>Member since:</strong> ${new Date().toLocaleDateString()}</div>
          </div>
          <div style="border-top:1px solid var(--border);padding-top:16px">
            <h4 style="margin-bottom:8px">Quick Stats</h4>
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;font-size:13px">
              <div>Patients: <strong>${DB.users.filter(u => u.role === 'patient').length}</strong></div>
              <div>Consultations: <strong>${DB.consultations.length}</strong></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>`;
}

function saveDoctorProfile() {
  const name = v('d-name').trim();
  const email = v('d-email').trim();
  const specialty = v('d-specialty').trim();

  if (!name || !email) {
    flash('d-saved', 'Name and email are required.', 'red');
    return;
  }

  currentUser.name = name;
  currentUser.email = email;
  currentUser.specialty = specialty;

  // Update in DB
  const userIndex = DB.users.findIndex(u => u.id === currentUser.id);
  if (userIndex !== -1) {
    DB.users[userIndex].name = name;
    DB.users[userIndex].email = email;
    DB.users[userIndex].specialty = specialty;
  }

  savePersistedData();
  flash('d-saved', 'Profile saved successfully!');
}
