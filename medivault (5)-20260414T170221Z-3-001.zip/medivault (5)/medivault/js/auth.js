/**
 * MediVault — auth.js
 * Login, registration, and auth rendering logic.
 */

// ============================================================
// AUTH STATE
// ============================================================
let authMode = 'login';   // 'login' | 'register'
let regRole  = 'patient'; // 'patient' | 'doctor'

// ============================================================
// RENDER AUTH SCREEN
// ============================================================
function renderAuth() {
  if (authMode === 'login') return renderLogin();
  return renderRegister();
}

function renderLogin() {
  return `
    <div class="auth-wrap">
      <div class="auth-card">
        <div class="brand">
          <div class="brand-icon">
            <svg viewBox="0 0 24 24"><path d="M22 12h-4l-3 9L9 3l-3 9H2"/></svg>
          </div>
          <h1>MediVault</h1>
          <p>Your personal health records system</p>
        </div>

        <div id="auth-alert"></div>

        <div class="form-group">
          <label>Email</label>
          <input id="l-email" type="email" value="maria@demo.com">
        </div>
        <div class="form-group">
          <label>Password</label>
          <input id="l-pass" type="password" value="demo123">
        </div>

        <button id="login-btn" class="btn btn-primary btn-full" onclick="doLogin()">Sign In</button>

        <div class="divider"><span>or try a demo</span></div>

        <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px">
          <button class="btn" style="justify-content:center;font-size:12px" onclick="quickLogin('patient')">🧑‍⚕️ Patient Demo</button>
          <button class="btn" style="justify-content:center;font-size:12px" onclick="quickLogin('doctor')">👨‍⚕️ Doctor Demo</button>
        </div>

        <div class="auth-toggle">No account? <a onclick="authMode='register';render()">Register here</a></div>
      </div>
    </div>`;
}

function renderRegister() {
  return `
    <div class="auth-wrap">
      <div class="auth-card">
        <div class="brand">
          <div class="brand-icon">
            <svg viewBox="0 0 24 24"><path d="M22 12h-4l-3 9L9 3l-3 9H2"/></svg>
          </div>
          <h1>Create Account</h1>
          <p>Join MediVault</p>
        </div>

        <div id="auth-alert"></div>

        <div class="form-group">
          <label>Full Name</label>
          <input id="r-name" placeholder="Juan Dela Cruz">
        </div>
        <div class="form-group">
          <label>Email</label>
          <input id="r-email" type="email" placeholder="you@email.com">
        </div>
        <div class="form-group">
          <label>Password</label>
          <input id="r-pass" type="password" placeholder="Min 6 characters">
        </div>
        <div class="form-group">
          <label>I am a</label>
          <div class="role-select">
            <div class="role-btn ${regRole === 'patient' ? 'active' : ''}" onclick="regRole='patient';render()">
              <span class="role-icon">🧑‍⚕️</span>
              <span class="role-label">Patient</span>
            </div>
            <div class="role-btn ${regRole === 'doctor' ? 'active' : ''}" onclick="regRole='doctor';render()">
              <span class="role-icon">👨‍⚕️</span>
              <span class="role-label">Doctor</span>
            </div>
          </div>
        </div>

        <button id="register-btn" class="btn btn-primary btn-full" onclick="doRegister()">Create Account</button>

        <div class="auth-toggle">Have an account? <a onclick="authMode='login';render()">Sign in</a></div>
      </div>
    </div>`;
}

// ============================================================
// AUTH ACTIONS
// ============================================================
function quickLogin(role) {
  currentUser   = DB.users.find(u => u.role === role);
  currentPage   = 'dashboard';
  render();
}

function doLogin() {
  // Add loading state
  setButtonLoading('login-btn', true);

  // Simulate network delay for better UX
  setTimeout(() => {
    const u = DB.users.find(x => x.email === v('l-email') && x.password === v('l-pass'));
    if (!u) {
      document.getElementById('auth-alert').innerHTML =
        '<div class="alert alert-red">Invalid email or password.</div>';
      setButtonLoading('login-btn', false);
      return;
    }
    currentUser = u;
    currentPage = 'dashboard';
    showToast('Welcome back, ' + u.name + '!', 'success');
    render();
  }, 800);
}

function doRegister() {
  // Add loading state
  setButtonLoading('register-btn', true);

  const name  = v('r-name').trim();
  const email = v('r-email').trim();
  const pass  = v('r-pass');

  if (!name || !email || !pass) {
    document.getElementById('auth-alert').innerHTML =
      '<div class="alert alert-red">Fill all fields.</div>';
    setButtonLoading('register-btn', false);
    return;
  }
  if (pass.length < 6) {
    document.getElementById('auth-alert').innerHTML =
      '<div class="alert alert-red">Password needs 6+ characters.</div>';
    setButtonLoading('register-btn', false);
    return;
  }
  if (DB.users.find(x => x.email === email)) {
    document.getElementById('auth-alert').innerHTML =
      '<div class="alert alert-red">Email already registered.</div>';
    setButtonLoading('register-btn', false);
    return;
  }

  // Simulate network delay
  setTimeout(() => {
    const nu = {
      id:       getNextId(),
      name,
      email,
      password: pass,
      role:     regRole,
      avatar:   name.split(' ').map(w => w[0]).join('').slice(0, 2).toUpperCase(),
    };

    DB.users.push(nu);

    if (regRole === 'patient') {
      DB.profiles[nu.id] = { name, age: '', birthdate: '', blood_type: '', sex: '', address: '', phone: '', philhealth: '', hmo: '' };
    }

    savePersistedData();

    currentUser = nu;
    currentPage = 'dashboard';
    showToast('Account created successfully! Welcome, ' + nu.name + '!', 'success');
    render();
  }, 1000);
}

function doLogout() {
  currentUser = null;
  currentPage = 'dashboard';
  modal       = null;
  render();
}
