/**
 * MediVault — app.js
 * Application entry point: state management, render engine, and utility helpers.
 *
 * Load order (see index.html):
 *   1. db.js          — in-memory data store
 *   2. icons.js       — SVG icon helpers
 *   3. auth.js        — login / register logic
 *   4. modals.js      — modal renderers and save actions
 *   5. pages-patient.js — patient page renderers
 *   6. pages-doctor.js  — doctor page renderers
 *   7. app.js         — this file (must be last)
 */

// ============================================================
// GLOBAL STATE
// ============================================================
let currentUser    = null;
let currentPage    = 'dashboard';
let activeTab      = 0;
let modal          = null;
let searchQuery    = '';
let selectedPatient= null;
let mobileMenuOpen = false;
let toolPanelOpen  = false;
let theme          = 'dark'; // 'dark' | 'light'
let notifications  = [];
let healthMetrics  = [];
let medicationReminders = [];
let emergencyContacts = [];
let appointments   = [];
let symptoms       = [];
let healthGoals    = [];
let familyMembers  = [];
let documents      = [];
let healthArticles = [];
let wearableData   = [];
let insuranceInfo  = null;
let allergies      = [];

// ============================================================
// UTILITY HELPERS
// ============================================================

/** Get value of an input element by id (returns '' if not found). */
function v(id) {
  const el = document.getElementById(id);
  return el ? el.value : '';
}

/** Return number of whole days since a date string (YYYY-MM-DD). */
function daysSince(d) {
  return Math.floor((new Date() - new Date(d)) / 86_400_000);
}

/** Calculate BMI from height (cm) and weight (kg) */
function calculateBMI(heightCm, weightKg) {
  if (!heightCm || !weightKg) return null;
  const heightM = heightCm / 100;
  return (weightKg / (heightM * heightM)).toFixed(1);
}

/** Get BMI category (Underweight, Normal, Overweight, Obese) */
function getBMICategory(bmi) {
  if (!bmi) return null;
  if (bmi < 18.5) return 'Underweight';
  if (bmi < 25) return 'Normal';
  if (bmi < 30) return 'Overweight';
  return 'Obese';
}

/** Check if medication is expired */
function isExpired(expiryDate) {
  if (!expiryDate) return false;
  return new Date(expiryDate) < new Date();
}

/** Search across multiple data types */
function searchData(query) {
  if (!query.trim()) return { visits: [], medications: [], labs: [] };
  const q = query.toLowerCase();
  const uid = currentUser.id;
  
  return {
    visits: DB.visits.filter(v => v.patient_id === uid && (v.reason.toLowerCase().includes(q) || v.doctor.toLowerCase().includes(q) || v.hospital.toLowerCase().includes(q))),
    medications: DB.medications.filter(m => m.patient_id === uid && (m.name.toLowerCase().includes(q) || m.notes.toLowerCase().includes(q))),
    labs: DB.lab_results.filter(l => l.patient_id === uid && (l.test_name.toLowerCase().includes(q) || l.facility.toLowerCase().includes(q) || l.results.toLowerCase().includes(q))),
  };
}

/** Get and increment the next unique id from DB. */
function getNextId() {
  return ++DB.nextId;
}

/** Flash a success/error message inside an element, then clear it after 2.5 s. */
function flash(id, msg, type = 'green') {
  const el = document.getElementById(id);
  if (el) {
    el.innerHTML = `<div class="alert alert-${type}">${msg}</div>`;
    setTimeout(() => { if (el) el.innerHTML = ''; }, 2500);
  }
}

/** Show loading state on a button */
function setButtonLoading(buttonId, loading = true) {
  const btn = document.getElementById(buttonId);
  if (btn) {
    if (loading) {
      btn.classList.add('btn-loading');
      btn.disabled = true;
    } else {
      btn.classList.remove('btn-loading');
      btn.disabled = false;
    }
  }
}

/** Show a toast notification */
function showToast(message, type = 'info', duration = 3000) {
  const toast = document.createElement('div');
  toast.className = `toast toast-${type}`;
  toast.innerHTML = `
    <div class="toast-content">
      <span class="toast-icon">${type === 'success' ? '✓' : type === 'error' ? '✕' : type === 'warning' ? '⚠' : 'ℹ'}</span>
      <span class="toast-message">${message}</span>
    </div>
  `;
  toast.style.cssText = `
    position: fixed;
    top: 20px;
    right: 20px;
    z-index: 1000;
    background: var(--bg2);
    border: 1px solid var(--border);
    border-radius: var(--radius);
    padding: 12px 16px;
    box-shadow: var(--shadow-lg);
    animation: slideInRight 0.3s ease-out;
    max-width: 300px;
  `;

  document.body.appendChild(toast);

  setTimeout(() => {
    toast.style.animation = 'slideOutRight 0.3s ease-in forwards';
    setTimeout(() => toast.remove(), 300);
  }, duration);
}

/** Upload profile picture */
function uploadProfilePicture() {
  const file = document.getElementById('profile-pic').files[0];
  if (!file) return;

  if (file.size > 2 * 1024 * 1024) { // 2MB limit
    showToast('Image too large. Please choose an image under 2MB.', 'error');
    return;
  }

  const reader = new FileReader();
  reader.onload = function(e) {
    currentUser.profilePicture = e.target.result;
    // Update the user in DB
    const userIndex = DB.users.findIndex(u => u.id === currentUser.id);
    if (userIndex !== -1) {
      DB.users[userIndex].profilePicture = e.target.result;
    }
    savePersistedData();
    render(); // Re-render to show the new picture
    showToast('Profile picture updated!', 'success');
  };
  reader.readAsDataURL(file);
}

/** Toggle between dark and light themes */
function toggleTheme() {
  theme = theme === 'dark' ? 'light' : 'dark';
  document.documentElement.setAttribute('data-theme', theme);
  localStorage.setItem('medivault-theme', theme);
  showToast(`Switched to ${theme === 'dark' ? 'dark' : 'light'} mode`, 'info');
  render(); // Re-render to update the theme toggle button icon
}

/** Initialize theme on app start */
function initTheme() {
  const savedTheme = localStorage.getItem('medivault-theme') || 'dark';
  theme = savedTheme;
  document.documentElement.setAttribute('data-theme', theme);
}

/** Emergency SOS function */
function triggerSOS() {
  if (confirm('🚨 EMERGENCY SOS\n\nThis will call emergency services and notify your emergency contacts. Are you sure?')) {
    showToast('🚨 SOS ACTIVATED - Emergency services notified!', 'error', 5000);
    // In a real app, this would trigger actual emergency calls
    setTimeout(() => {
      showToast('Emergency contacts notified', 'warning', 4000);
    }, 1000);
  }
}

// ============================================================
// AI HEALTH ANALYTICS
// ============================================================

/** Generate AI-powered health insights */
function generateHealthInsights() {
  const uid = currentUser.id;
  const metrics = healthMetrics.filter(m => m.patient_id === uid);
  const medications = DB.medications.filter(m => m.patient_id === uid);
  const visits = DB.visits.filter(v => v.patient_id === uid);

  let insights = {
    summary: '',
    message: '',
    recommendations: []
  };

  // Weight trend analysis
  const weightMetrics = metrics.filter(m => m.type === 'weight').sort((a, b) => new Date(a.date) - new Date(b.date));
  if (weightMetrics.length >= 3) {
    const recent = weightMetrics.slice(-3);
    const avgRecent = recent.reduce((sum, m) => sum + m.value, 0) / recent.length;
    const avgOlder = weightMetrics.slice(0, -3).reduce((sum, m) => sum + m.value, 0) / Math.max(1, weightMetrics.length - 3);

    if (avgRecent > avgOlder * 1.05) {
      insights.recommendations.push('Consider reviewing your diet and exercise routine');
      insights.message += '⚠️ Weight trending upward. ';
    } else if (avgRecent < avgOlder * 0.95) {
      insights.recommendations.push('Great job maintaining healthy weight!');
      insights.message += '✅ Weight stable or improving. ';
    }
  }

  // Medication adherence check
  const activeMeds = medications.filter(m => !isExpired(m.expiry_date));
  if (activeMeds.length > 0) {
    insights.message += `You have ${activeMeds.length} active medication${activeMeds.length > 1 ? 's' : ''}. `;
    insights.recommendations.push('Remember to take medications as prescribed');
  }

  // Visit frequency
  const recentVisits = visits.filter(v => daysSince(v.date) < 365);
  if (recentVisits.length === 0) {
    insights.recommendations.push('Consider scheduling a check-up with your doctor');
    insights.message += 'No recent doctor visits. ';
  } else {
    insights.message += `${recentVisits.length} visit${recentVisits.length > 1 ? 's' : ''} in the past year. `;
  }

  // Blood pressure analysis
  const bpMetrics = metrics.filter(m => m.type === 'blood_pressure');
  if (bpMetrics.length > 0) {
    const latest = bpMetrics[bpMetrics.length - 1];
    const [systolic, diastolic] = latest.value.split('/').map(Number);

    if (systolic >= 140 || diastolic >= 90) {
      insights.recommendations.push('Monitor blood pressure closely - consider lifestyle changes');
      insights.message += '⚠️ Recent blood pressure reading is elevated. ';
    } else if (systolic < 120 && diastolic < 80) {
      insights.message += '✅ Blood pressure looks good. ';
    }
  }

  if (insights.recommendations.length === 0) {
    insights.summary = 'Your health metrics look good! Keep up the healthy habits.';
    insights.message = insights.message || '✅ All systems looking good!';
  } else {
    insights.summary = `Found ${insights.recommendations.length} area${insights.recommendations.length > 1 ? 's' : ''} for attention.`;
  }

  return insights;
}

/** Generate health summary */
function generateHealthSummary() {
  const uid = currentUser.id;
  const metrics = healthMetrics.filter(m => m.patient_id === uid);
  const medications = DB.medications.filter(m => m.patient_id === uid);
  const visits = DB.visits.filter(v => v.patient_id === uid);

  const summary = {
    totalMetrics: metrics.length,
    activeMedications: medications.filter(m => !isExpired(m.expiry_date)).length,
    recentVisits: visits.filter(v => daysSince(v.date) < 90).length,
    lastVisit: visits.length > 0 ? visits.sort((a, b) => new Date(b.date) - new Date(a.date))[0] : null,
    healthScore: calculateHealthScore(metrics, medications, visits)
  };

  return summary;
}

/** Calculate a simple health score (0-100) */
function calculateHealthScore(metrics, medications, visits) {
  let score = 50; // Base score

  // Recent metrics (+20)
  const recentMetrics = metrics.filter(m => daysSince(m.date) < 30);
  score += Math.min(20, recentMetrics.length * 5);

  // Active medications (-10 if expired ones exist)
  const expiredMeds = medications.filter(m => isExpired(m.expiry_date));
  score -= expiredMeds.length * 10;

  // Recent visits (+15)
  const recentVisits = visits.filter(v => daysSince(v.date) < 180);
  score += Math.min(15, recentVisits.length * 5);

  // Regular check-ups (+15)
  if (visits.length > 0) {
    const lastVisit = Math.max(...visits.map(v => daysSince(v.date)));
    if (lastVisit < 365) score += 15;
    else if (lastVisit < 730) score += 10;
  }

  return Math.max(0, Math.min(100, score));
}

/** Show modal with health insights */
function showModal(type, data) {
  if (type === 'health-insights') {
    modal = {
      type: 'insights',
      title: 'AI Health Insights',
      content: `
        <div class="insights-modal">
          <div class="insights-summary">
            <h3>${data.summary}</h3>
            <p>${data.message}</p>
          </div>
          ${data.recommendations.length > 0 ? `
            <div class="insights-recommendations">
              <h4>Recommendations:</h4>
              <ul>
                ${data.recommendations.map(rec => `<li>${rec}</li>`).join('')}
              </ul>
            </div>
          ` : ''}
        </div>
      `
    };
  } else if (type === 'health-summary') {
    modal = {
      type: 'summary',
      title: 'Health Summary',
      content: `
        <div class="summary-modal">
          <div class="summary-stats">
            <div class="stat-item">
              <span class="stat-value">${data.totalMetrics}</span>
              <span class="stat-label">Health Metrics</span>
            </div>
            <div class="stat-item">
              <span class="stat-value">${data.activeMedications}</span>
              <span class="stat-label">Active Medications</span>
            </div>
            <div class="stat-item">
              <span class="stat-value">${data.recentVisits}</span>
              <span class="stat-label">Visits (90 days)</span>
            </div>
            <div class="stat-item">
              <span class="stat-value">${data.healthScore}</span>
              <span class="stat-label">Health Score</span>
            </div>
          </div>
          ${data.lastVisit ? `
            <div class="last-visit">
              <p>Last visit: ${data.lastVisit.doctor} on ${data.lastVisit.date}</p>
            </div>
          ` : ''}
        </div>
      `
    };
  }
  render();
}

/** Voice command handler */
function initVoiceCommands() {
  if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
    voiceEnabled = true;
    const recognition = new (window.SpeechRecognition || window.webkitSpeechRecognition)();
    recognition.continuous = false;
    recognition.interimResults = false;
    recognition.lang = 'en-US';

    recognition.onresult = (event) => {
      const command = event.results[0][0].transcript.toLowerCase();
      processVoiceCommand(command);
    };

    window.voiceRecognition = recognition;
  }
}

// ============================================================
// ADVANCED AI VOICE SYSTEM
// ============================================================

/** Advanced voice command processing with NLP */
function processVoiceCommand(command) {
  const cmd = command.toLowerCase().trim();
  showToast(`🎤 Heard: "${command}"`, 'info', 2000);

  // Voice response system
  function speak(text) {
    if ('speechSynthesis' in window) {
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.rate = 0.9;
      utterance.pitch = 1;
      utterance.volume = 0.8;
      window.speechSynthesis.speak(utterance);
    }
  }

  // Enhanced command patterns with synonyms
  const commands = {
    // Navigation commands
    dashboard: /\b(dashboard|home|main|start|menu)\b/,
    profile: /\b(profile|account|settings|my info|personal)\b/,
    medical: /\b(medical|history|records|health records|past visits)\b/,
    medications: /\b(medication|meds|pills|drugs|prescription)\b/,
    visits: /\b(visits|appointments|doctor visits|checkups)\b/,
    labs: /\b(labs?|tests?|results?|blood|urine)\b/,
    health: /\b(health|metrics|vitals|measurements|stats)\b/,
    vaccinations: /\b(vaccinations?|shots?|immunizations?)\b/,
    appointments: /\b(appointments?|schedule|booking|upcoming)\b/,
    symptoms: /\b(symptoms?|symptom tracker|symptom log|pain|aches)\b/,
    goals: /\b(goals?|health goals|objectives|targets)\b/,
    family: /\b(family|family health|relatives|members)\b/,
    education: /\b(education|articles|learn|health tips|information)\b/,
    vaccinations: /\b(vaccinations?|shots?|immunizations?)\b/,

    // Action commands
    emergency: /\b(emergency|sos|help|urgent|crisis)\b/,
    theme: /\b(theme|dark|light|mode|appearance)\b/,
    search: /\b(search|find|look for|query)\b/,
    export: /\b(export|download|pdf|save|print)\b/,

    // Data entry commands
    add_weight: /\b(add|record|log|enter)\b.*\b(weight|kg|pounds?|lbs?)\b/,
    add_blood_pressure: /\b(add|record|log|enter)\b.*\b(blood pressure|bp|systolic|diastolic)\b/,
    add_temperature: /\b(add|record|log|enter)\b.*\b(temperature|temp|fever)\b/,
    add_medication: /\b(add|record|log|enter)\b.*\b(medication|pill|drug|dose)\b/,

    // AI features
    analyze: /\b(analyze|check|review|assess|evaluate)\b.*\b(health|trends|progress|status)\b/,
    insights: /\b(insights?|advice|suggestions?|recommendations?)\b/,
    summary: /\b(summary|overview|status|report)\b/
  };

  // Extract numbers from command
  const numbers = cmd.match(/\d+(\.\d+)?/g) || [];
  const number = numbers.length > 0 ? parseFloat(numbers[0]) : null;

  // Process commands
  if (commands.dashboard.test(cmd)) {
    navigate('dashboard');
    speak('Opening dashboard');
  }
  else if (commands.profile.test(cmd)) {
    navigate('profile');
    speak('Opening your profile');
  }
  else if (commands.medical.test(cmd)) {
    navigate('medical');
    speak('Showing medical history');
  }
  else if (commands.medications.test(cmd)) {
    navigate('medications');
    speak('Opening medications');
  }
  else if (commands.visits.test(cmd)) {
    navigate('visits');
    speak('Showing visit tracker');
  }
  else if (commands.labs.test(cmd)) {
    navigate('labs');
    speak('Opening lab results');
  }
  else if (commands.health.test(cmd)) {
    navigate('health');
    speak('Showing health metrics');
  }
  else if (commands.vaccinations.test(cmd)) {
    navigate('vaccinations');
    speak('Opening vaccinations');
  }
  else if (commands.appointments.test(cmd)) {
    navigate('appointments');
    speak('Opening appointments');
  }
  else if (commands.symptoms.test(cmd)) {
    navigate('symptoms');
    speak('Opening symptom tracker');
  }
  else if (commands.goals.test(cmd)) {
    navigate('goals');
    speak('Opening health goals');
  }
  else if (commands.family.test(cmd)) {
    navigate('family');
    speak('Opening family health');
  }
  else if (commands.education.test(cmd)) {
    navigate('education');
    speak('Opening health education');
  }
  else if (commands.emergency.test(cmd)) {
    triggerSOS();
    speak('Emergency mode activated. Help is on the way.');
  }
  else if (commands.theme.test(cmd)) {
    toggleTheme();
    speak(`Switched to ${theme} theme`);
  }
  else if (commands.export.test(cmd)) {
    exportToPDF();
    speak('Exporting your medical records');
  }
  else if (commands.add_weight.test(cmd) && number) {
    const unit = cmd.includes('pound') || cmd.includes('lb') ? 'lbs' : 'kg';
    addHealthMetric('weight', number);
    speak(`Recorded weight: ${number} ${unit}`);
  }
  else if (commands.add_blood_pressure.test(cmd) && numbers.length >= 2) {
    const systolic = parseInt(numbers[0]);
    const diastolic = parseInt(numbers[1]);
    addHealthMetric('blood_pressure', `${systolic}/${diastolic}`);
    speak(`Recorded blood pressure: ${systolic} over ${diastolic}`);
  }
  else if (commands.add_temperature.test(cmd) && number) {
    const unit = cmd.includes('fahrenheit') || cmd.includes('f') ? '°F' : '°C';
    addHealthMetric('temperature', number);
    speak(`Recorded temperature: ${number} ${unit}`);
  }
  else if (commands.analyze.test(cmd)) {
    const insights = generateHealthInsights();
    speak(insights.summary);
    showToast(insights.message, 'info', 5000);
  }
  else if (commands.insights.test(cmd)) {
    const insights = generateHealthInsights();
    speak('Here are your health insights');
    showModal('health-insights', insights);
  }
  else if (commands.summary.test(cmd)) {
    const summary = generateHealthSummary();
    speak('Here is your health summary');
    showModal('health-summary', summary);
  }
  else if (commands.search.test(cmd)) {
    // Extract search query after "search" or "find"
    const searchTerm = cmd.replace(/\b(search|find|look for|query)\b/, '').trim();
    if (searchTerm) {
      searchQuery = searchTerm;
      navigate('dashboard'); // Search results shown on dashboard
      speak(`Searching for ${searchTerm}`);
    } else {
      speak('What would you like to search for?');
    }
  }
  else {
    // Fuzzy matching for common mispronunciations
    const fuzzyMatches = {
      'medication': commands.medications,
      'medicines': commands.medications,
      'pills': commands.medications,
      'drugs': commands.medications,
      'history': commands.medical,
      'records': commands.medical,
      'visits': commands.visits,
      'appointments': commands.visits,
      'labs': commands.labs,
      'tests': commands.labs,
      'health': commands.health,
      'vitals': commands.health,
      'vaccines': commands.vaccinations,
      'shots': commands.vaccinations,
      'schedule': commands.appointments,
      'booking': commands.appointments,
      'symptom': commands.symptoms,
      'pain': commands.symptoms,
      'aches': commands.symptoms,
      'goal': commands.goals,
      'objectives': commands.goals,
      'targets': commands.goals,
      'relatives': commands.family,
      'members': commands.family,
      'learn': commands.education,
      'articles': commands.education,
      'tips': commands.education
    };

    let matched = false;
    for (const [word, pattern] of Object.entries(fuzzyMatches)) {
      if (cmd.includes(word)) {
        // Re-run with the corrected term
        const correctedCmd = cmd.replace(new RegExp(`\\b${word}\\b`, 'g'), Object.keys(commands).find(key => commands[key] === pattern));
        processVoiceCommand(correctedCmd);
        matched = true;
        break;
      }
    }

    if (!matched) {
      speak('Command not recognized. Try saying dashboard, profile, medical history, medications, appointments, symptoms, goals, or emergency.');
      showToast('Command not recognized. Try "dashboard", "profile", "medical", "medications", "appointments", "symptoms", "goals", or "emergency"', 'warning', 4000);
    }
  }
}

function startVoiceCommand() {
  if (window.voiceRecognition) {
    try {
      window.voiceRecognition.start();
      showToast('🎤 Listening... Say a command like "show dashboard" or "add weight 70 kg"', 'info', 3000);
    } catch (error) {
      showToast('Voice recognition already active', 'warning');
    }
  } else {
    showToast('Voice commands not supported in this browser', 'error');
  }
}

/** Start continuous voice listening mode */
function startContinuousVoiceMode() {
  if (!window.voiceRecognition) {
    showToast('Voice commands not supported in this browser', 'error');
    return;
  }

  if (window.voiceRecognition.continuous) {
    // Already in continuous mode
    stopVoiceCommands();
    return;
  }

  window.voiceRecognition.continuous = true;
  window.voiceRecognition.start();
  showToast('🎤 Continuous listening activated. Say "stop listening" to exit.', 'success', 4000);

  // Add stop command to recognition
  const originalOnResult = window.voiceRecognition.onresult;
  window.voiceRecognition.onresult = (event) => {
    const command = event.results[event.results.length - 1][0].transcript.toLowerCase();
    if (command.includes('stop listening') || command.includes('exit voice') || command.includes('turn off voice')) {
      stopVoiceCommands();
      showToast('Voice mode deactivated', 'info');
      return;
    }
    originalOnResult(event);
  };
}

/** Stop voice commands */
function stopVoiceCommands() {
  if (window.voiceRecognition) {
    window.voiceRecognition.stop();
    window.voiceRecognition.continuous = false;
    showToast('Voice commands stopped', 'info');
  }
}

/** Export medical records to PDF */
function exportToPDF() {
  const { jsPDF } = window.jspdf;
  const doc = new jsPDF();

  doc.setFontSize(20);
  doc.text('MediVault Medical Records', 20, 30);
  doc.setFontSize(12);
  doc.text(`Patient: ${currentUser.name}`, 20, 50);
  doc.text(`Date: ${new Date().toLocaleDateString()}`, 20, 60);

  // Add medical data
  let yPos = 80;
  doc.setFontSize(14);
  doc.text('Medical History:', 20, yPos);
  yPos += 20;

  DB.medical_history.filter(h => h.patient_id === currentUser.id).forEach(item => {
    doc.setFontSize(10);
    doc.text(`${item.type}: ${item.title}`, 30, yPos);
    yPos += 10;
    if (yPos > 270) {
      doc.addPage();
      yPos = 30;
    }
  });

  doc.save(`medivault-records-${currentUser.name.replace(' ', '-')}.pdf`);
  showToast('Medical records exported to PDF', 'success');
}

/** Add health metric */
function addHealthMetric(type, value, date = new Date().toISOString().split('T')[0]) {
  healthMetrics.push({
    id: getNextId(),
    patient_id: currentUser.id,
    type,
    value: parseFloat(value),
    date,
    timestamp: new Date().toISOString()
  });
  showToast(`${type} recorded: ${value}`, 'success');
}

/** Schedule medication reminder */
function scheduleMedicationReminder(medicationId, time) {
  const med = DB.medications.find(m => m.id === medicationId);
  if (med) {
    medicationReminders.push({
      id: getNextId(),
      medication_id: medicationId,
      medication_name: med.name,
      time,
      patient_id: currentUser.id,
      active: true
    });
    showToast(`Reminder set for ${med.name} at ${time}`, 'success');
  }
}

// ============================================================
// NAVIGATION
// ============================================================
function navigate(page) {
  currentPage      = page;
  activeTab        = 0;
  modal            = null;
  selectedPatient  = null;
  mobileMenuOpen   = false; // Close mobile menu on navigation
  render();
  
  // Initialize charts for health page
  if (page === 'health') {
    setTimeout(() => initHealthCharts(), 100);
  }
}

function toggleMobileMenu() {
  mobileMenuOpen = !mobileMenuOpen;
  render();
}

function toggleToolsPanel() {
  toolPanelOpen = !toolPanelOpen;
  render();
}

function openQuickTool(tool) {
  toolPanelOpen = false;
  const isDoc = currentUser && currentUser.role === 'doctor';

  switch (tool) {
    case 'appointments':
      navigate(isDoc ? 'schedule' : 'appointments');
      break;
    case 'goals':
      navigate(isDoc ? 'consultations' : 'goals');
      break;
    case 'medications':
      navigate(isDoc ? 'patients' : 'medications');
      break;
    case 'documents':
      navigate(isDoc ? 'patients' : 'documents');
      break;
    case 'contact':
      showToast('Quick help: check your care team or emergency contacts for fast support.', 'info');
      break;
    default:
      showToast('Tool not available yet', 'warning');
  }
}

// ============================================================
// RENDER ENGINE
// ============================================================
function render() {
  document.getElementById('root').innerHTML = currentUser ? renderApp() : renderAuth();
}

/** Render the full authenticated app shell (sidebar + main content). */
function renderApp() {
  const isDoc = currentUser.role === 'doctor';

  const nav = isDoc
    ? [
        { id: 'dashboard',     label: 'Dashboard',     icon: iconHome() },
        { id: 'profile',       label: 'My Profile',    icon: iconUser() },
        { id: 'patients',      label: 'Patients',       icon: iconUsers() },
        { id: 'consultations', label: 'Consultations',  icon: iconClipboard() },
        { id: 'schedule',      label: 'Schedule',       icon: iconCalendar() },
      ]
    : [
        { id: 'dashboard',     label: 'Dashboard',       icon: iconHome() },
        { id: 'profile',       label: 'My Profile',      icon: iconUser() },
        { id: 'medical',       label: 'Medical History', icon: iconHeart() },
        { id: 'visits',        label: 'Visit Tracker',   icon: iconMapPin() },
        { id: 'medications',   label: 'Medications',     icon: iconPill() },
        { id: 'vaccinations',  label: 'Vaccinations',    icon: iconShield() },
        { id: 'labs',          label: 'Lab Results',     icon: iconTestTube() },
        { id: 'health',        label: 'Health Metrics',  icon: iconActivity() },
        { id: 'appointments',  label: 'Appointments',    icon: iconCalendar() },
        { id: 'symptoms',      label: 'Symptom Tracker', icon: iconThermometer() },
        { id: 'goals',         label: 'Health Goals',    icon: iconTarget() },
        { id: 'family',        label: 'Family Health',   icon: iconUsers() },
        { id: 'documents',     label: 'Documents',       icon: iconFile() },
        { id: 'education',     label: 'Health Education',icon: iconBookOpen() },
      ];

  return `
  <div class="app-layout">
    <!-- Mobile Menu Button -->
    <button class="btn btn-icon mobile-menu-btn" onclick="toggleMobileMenu()" style="display:none">
      <svg viewBox="0 0 24 24" stroke="currentColor" fill="none" stroke-width="2">
        <path d="M4 6h16M4 12h16M4 18h16"/>
      </svg>
    </button>

    <!-- Mobile Menu Overlay -->
    ${mobileMenuOpen ? '<div class="mobile-overlay" onclick="toggleMobileMenu()"></div>' : ''}

    <!-- ── Sidebar ── -->
    <div class="sidebar ${mobileMenuOpen ? 'open' : ''}">
      <div class="sidebar-header">
        <div class="sidebar-brand">
          <div class="sidebar-brand-icon">
            <svg viewBox="0 0 24 24" stroke="currentColor" fill="none" stroke-width="2">
              <path d="M22 12h-4l-3 9L9 3l-3 9H2"/>
            </svg>
          </div>
          <span class="sidebar-brand-name">MediVault</span>
        </div>
      </div>

      <div class="sidebar-user">
        <div class="user-badge">
          <div class="user-avatar">${currentUser.avatar}</div>
          <div class="user-info">
            <div class="user-name">${currentUser.name}</div>
            <div class="user-role">${currentUser.role === 'doctor' ? 'Doctor' : 'Patient'}</div>
          </div>
        </div>
      </div>

      <nav class="sidebar-nav">
        ${nav.map(item => `
          <div class="nav-item ${currentPage === item.id ? 'active' : ''}" onclick="navigate('${item.id}')">
            ${item.icon}
            <span>${item.label}</span>
          </div>`).join('')}
      </nav>

      <div class="sidebar-tools ${toolPanelOpen ? 'open' : ''}">
        <div class="tools-header">
          <div>
            <div class="tools-title">Quick Tools</div>
            <div class="tools-subtitle">Access frequently used actions</div>
          </div>
          <button class="btn btn-icon" onclick="toggleToolsPanel()" title="Close Quick Tools">
            ${iconX()}
          </button>
        </div>
        <div class="tools-grid">
          <button class="tool-card" onclick="openQuickTool('appointments')">
            ${iconCalendar()}<span>Schedule Visit</span>
          </button>
          <button class="tool-card" onclick="openQuickTool('medications')">
            ${iconPlus()}<span>Manage Meds</span>
          </button>
          <button class="tool-card" onclick="openQuickTool('goals')">
            ${iconCheck()}<span>Health Goals</span>
          </button>
          <button class="tool-card" onclick="openQuickTool('documents')">
            ${iconBookOpen()}<span>Upload Docs</span>
          </button>
          <button class="tool-card" onclick="openQuickTool('contact')">
            ${iconPhone()}<span>Contact Support</span>
          </button>
        </div>
      </div>

      <div class="sidebar-footer">
        <!-- Quick Actions -->
        <div class="sidebar-actions">
          <button class="btn btn-icon" onclick="toggleTheme()" title="Toggle Theme (${theme === 'dark' ? 'Light' : 'Dark'} Mode)">
            <svg viewBox="0 0 24 24" stroke="currentColor" fill="none" stroke-width="2">
              ${theme === 'dark' 
                ? '<path d="M12 3v1m0 16v1m9-9h-1M4 12H3m15.364 6.364l-.707-.707M6.343 6.343l-.707-.707m12.728 0l-.707.707M6.343 17.657l-.707.707M16 12a4 4 0 11-8 0 4 4 0 018 0z"/>' 
                : '<path d="M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0012 21a9.003 9.003 0 008.354-5.646z"/>'}
            </svg>
          </button>
          <button class="btn btn-icon" onclick="toggleToolsPanel()" title="Open Quick Tools">
            ${iconPlus()}
          </button>
          <button class="btn btn-danger btn-icon" onclick="triggerSOS()" title="Emergency SOS">
            <svg viewBox="0 0 24 24" stroke="currentColor" fill="none" stroke-width="2">
              <path d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.964-.833-2.732 0L4.082 16.5c-.77.833.192 2.5 1.732 2.5z"/>
            </svg>
          </button>
        </div>

        <div class="nav-item" onclick="doLogout()">
          ${iconLogout()}
          <span>Sign out</span>
        </div>
      </div>
    </div>

    <!-- ── Main Content ── -->
    <div class="main-content">
      ${renderPage()}
      ${modal ? renderModal() : ''}
    </div>
  </div>`;
}

/** Dispatch to the correct page renderer based on role + currentPage. */
function renderPage() {
  if (currentUser.role === 'doctor') {
    if (currentPage === 'dashboard')     return renderDoctorDashboard();
    if (currentPage === 'profile')       return renderDoctorProfile();
    if (currentPage === 'patients')      return renderDoctorPatients();
    if (currentPage === 'consultations') return renderDoctorConsultations();
    if (currentPage === 'schedule')      return renderDoctorSchedule();
  } else {
    if (currentPage === 'dashboard')    return renderPatientDashboard();
    if (currentPage === 'profile')      return renderProfile();
    if (currentPage === 'medical')      return renderMedical();
    if (currentPage === 'visits')       return renderVisits();
    if (currentPage === 'medications')  return renderMedications();
    if (currentPage === 'vaccinations') return renderVaccinations();
    if (currentPage === 'labs')         return renderLabResults();
    if (currentPage === 'health')       return renderHealth();
    if (currentPage === 'documents')    return renderDocuments();
    if (currentPage === 'appointments') return renderAppointments();
    if (currentPage === 'symptoms')     return renderSymptoms();
    if (currentPage === 'goals')        return renderGoals();
    if (currentPage === 'family')       return renderFamily();
    if (currentPage === 'education')    return renderEducation();
  }
  return '<div class="page-body"><p style="color:var(--text2)">Page not found.</p></div>';
}

// ============================================================
// BOOT
// ============================================================
initTheme();
render();
